# Input-data documentation

This directory documents the source materials and fields required by the analysis. Source workbooks are not redistributed in the repository.

CEADs and EDGAR provide the city-level CO2 series. Municipal statistical yearbooks provide the socioeconomic indicators used in the pathway and predictor analyses. The required fields, units, and source roles are listed in `input_schema.csv`.

Users who obtain the source materials independently can construct the analysis panel with the documented schema and the data-preparation script. The `results/` directory contains the aggregate outputs reported in the manuscript.
