"""
论文2 模块1: 数据准备
=====================
从共享面板数据出发, 为 DTW 聚类准备标准化排放时序矩阵.

功能:
1. 加载面板数据
2. 筛选排放时序完整度足够的城市
3. 缺失值插值
4. Z-score 标准化 (保留形态, 消除量级)
5. 输出可直接用于 DTW 的矩阵
"""

import sys
import numpy as np
import pandas as pd
from pathlib import Path

# 添加项目根目录到 path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from shared.utils.emission_processor import load_panel, get_emission_ts


def prepare_emission_matrix(min_completeness: float = 0.80,
                            year_range: tuple = (2001, 2019),
                            source_filter: str = 'ceads') -> pd.DataFrame:
    """
    准备排放时序矩阵, 用于后续 DTW 聚类.
    
    Args:
        min_completeness: 最低时序完整度 (0-1), 低于此的城市被剔除
        year_range: 分析年份范围
        source_filter: 'ceads' 仅用 CEADs 城市, 'all' 全部
    
    Returns:
        DataFrame: 城市(行) × 年份(列) 的排放矩阵, 已插值和标准化
    """
    print(f"准备排放时序矩阵: {year_range[0]}-{year_range[1]}")
    
    # 1. 加载数据
    panel = load_panel()
    
    # 筛选年份和来源
    mask = (panel['year'] >= year_range[0]) & (panel['year'] <= year_range[1])
    if source_filter == 'ceads':
        mask &= panel['co2_source'].isin(['CEADs', 'EDGAR_corrected'])
    panel = panel[mask]
    
    # 2. 构建宽格式矩阵
    pivot = panel.pivot_table(index='city', columns='year',
                              values='co2_mt', aggfunc='first')
    
    n_years = year_range[1] - year_range[0] + 1
    all_years = list(range(year_range[0], year_range[1] + 1))
    # 确保所有年份列存在
    for y in all_years:
        if y not in pivot.columns:
            pivot[y] = np.nan
    pivot = pivot[all_years]
    
    # 3. 筛选完整度
    completeness = pivot.notna().mean(axis=1)
    qualified = completeness >= min_completeness
    
    n_before = len(pivot)
    pivot = pivot[qualified]
    n_after = len(pivot)
    
    print(f"  完整度筛选: {n_before} → {n_after} 城市 "
          f"(阈值={min_completeness:.0%})")
    
    # 4. 线性插值填补缺失
    n_missing_before = pivot.isna().sum().sum()
    pivot = pivot.interpolate(axis=1, method='linear', limit_direction='both')
    n_missing_after = pivot.isna().sum().sum()
    print(f"  插值: {n_missing_before} → {n_missing_after} 缺失值")
    
    # 丢弃仍有缺失的城市
    pivot = pivot.dropna()
    print(f"  最终: {len(pivot)} 城市, {len(pivot.columns)} 年")
    
    return pivot


def zscore_normalize(matrix: pd.DataFrame) -> pd.DataFrame:
    """
    Z-score 标准化: 每个城市的时序均值=0, 标准差=1.
    保留排放轨迹的形态, 消除绝对量级差异.
    """
    means = matrix.mean(axis=1)
    stds = matrix.std(axis=1)
    stds = stds.replace(0, 1)  # 避免除零
    normalized = matrix.sub(means, axis=0).div(stds, axis=0)
    return normalized


def minmax_normalize(matrix: pd.DataFrame) -> pd.DataFrame:
    """
    Min-Max 标准化: 每个城市的时序缩放到 [0, 1].
    """
    mins = matrix.min(axis=1)
    maxs = matrix.max(axis=1)
    ranges = maxs - mins
    ranges = ranges.replace(0, 1)
    normalized = matrix.sub(mins, axis=0).div(ranges, axis=0)
    return normalized


if __name__ == '__main__':
    # 准备 CEADs 城市排放矩阵 (2001-2019)
    raw_matrix = prepare_emission_matrix(
        min_completeness=0.80,
        year_range=(2001, 2019),
        source_filter='ceads'
    )
    
    # Z-score 标准化
    std_matrix = zscore_normalize(raw_matrix)
    
    print(f"\n原始矩阵形状: {raw_matrix.shape}")
    print(f"标准化矩阵形状: {std_matrix.shape}")
    print(f"\n标准化后前5城市:")
    print(std_matrix.head().round(3))
    
    # 存储
    outdir = PROJECT_ROOT / 'runtime_output'
    outdir.mkdir(exist_ok=True)
    raw_matrix.to_csv(outdir / 'emission_matrix_raw.csv', encoding='utf-8-sig')
    std_matrix.to_csv(outdir / 'emission_matrix_zscore.csv', encoding='utf-8-sig')
    print(f"\n已保存到 {outdir}")
