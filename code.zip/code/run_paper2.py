"""
论文2 主运行脚本 — run_paper2.py
=================================
按顺序执行所有分析模块, 或按需选择特定步骤.

用法:
    python run_paper2.py           # 执行全部
    python run_paper2.py --step 3  # 仅执行 Step 3
"""

import sys
import argparse
import numpy as np
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
CODE_DIR = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(CODE_DIR))

OUTPUT_DIR = PROJECT_ROOT / 'runtime_output'
OUTPUT_DIR.mkdir(exist_ok=True)


def step1_data_preparation():
    """Step 1: 数据准备 — 排放时序矩阵"""
    print("\n" + "=" * 60)
    print("STEP 1: 数据准备")
    print("=" * 60)
    from s1_data_preparation import prepare_emission_matrix, zscore_normalize
    
    raw = prepare_emission_matrix(
        min_completeness=0.80,
        year_range=(2001, 2019),
        source_filter='ceads'
    )
    std = zscore_normalize(raw)
    
    raw.to_csv(OUTPUT_DIR / 'emission_matrix_raw.csv', encoding='utf-8-sig')
    std.to_csv(OUTPUT_DIR / 'emission_matrix_zscore.csv', encoding='utf-8-sig')
    
    return raw, std


def step2_dtw_clustering(raw, std):
    """Step 2: DTW 聚类 + 小聚类合并"""
    print("\n" + "=" * 60)
    print("STEP 2: DTW 聚类")
    print("=" * 60)
    from s2_dtw_clustering import run_full_analysis
    import pandas as pd
    
    results = run_full_analysis(raw, std, k_range=range(3, 9))
    
    # 合并小聚类 (≤5 城市) 到最近的大聚类
    cluster_file = OUTPUT_DIR / 'city_clusters.csv'
    if cluster_file.exists():
        clusters = pd.read_csv(cluster_file)
        counts = clusters['cluster'].value_counts()
        small_clusters = counts[counts <= 5].index.tolist()
        
        if small_clusters:
            print(f"\n[合并] 发现小聚类: {small_clusters} (各≤5城市)")
            # 计算各聚类的排放均值序列
            cluster_means = {}
            for c in clusters['cluster'].unique():
                cities = clusters[clusters['cluster']==c]['city'].tolist()
                cluster_means[c] = raw.loc[raw.index.isin(cities)].mean(axis=0).values
            
            for sc in small_clusters:
                # 找排放轨迹最近的大聚类
                sc_mean = cluster_means[sc]
                best_target, best_dist = None, float('inf')
                for c in clusters['cluster'].unique():
                    if c in small_clusters:
                        continue
                    dist = np.sqrt(np.nansum((sc_mean - cluster_means[c])**2))
                    if dist < best_dist:
                        best_dist = dist
                        best_target = c
                
                n_moved = (clusters['cluster']==sc).sum()
                print(f"  类{sc} ({n_moved}城) → 合并至 类{best_target}")
                clusters.loc[clusters['cluster']==sc, 'cluster'] = best_target
            
            # 重新编号使聚类连续
            old_ids = sorted(clusters['cluster'].unique())
            id_map = {old: new+1 for new, old in enumerate(old_ids)}
            clusters['cluster'] = clusters['cluster'].map(id_map)
            
            clusters.to_csv(cluster_file, index=False, encoding='utf-8-sig')
            new_counts = clusters['cluster'].value_counts().sort_index()
            print(f"  合并后: {dict(new_counts)}")
    
    return results


def step3_peak_detection(raw):
    """Step 3: 达峰状态判定"""
    print("\n" + "=" * 60)
    print("STEP 3: 达峰状态判定")
    print("=" * 60)
    from s3_peak_detection import analyze_all_cities
    
    peak = analyze_all_cities(raw)
    peak.to_csv(OUTPUT_DIR / 'peak_status.csv', index=False, encoding='utf-8-sig')
    return peak


def step4_xgboost_shap():
    """Step 4: XGBoost + SHAP"""
    print("\n" + "=" * 60)
    print("STEP 4: XGBoost + SHAP")
    print("=" * 60)
    from s4_xgboost_shap import run_global_analysis, run_cluster_analysis
    from shared.utils.emission_processor import load_panel
    import pandas as pd
    
    panel = load_panel()
    global_result = run_global_analysis(panel)
    
    cluster_file = OUTPUT_DIR / 'city_clusters.csv'
    if cluster_file.exists():
        city_clusters = pd.read_csv(cluster_file)
        run_cluster_analysis(panel, city_clusters)
    
    return global_result


def step5_monte_carlo():
    """Step 5: Scenario simulation, backtesting, and panel FE comparison."""
    print("\n" + "=" * 60)
    print("STEP 5: Scenario simulation")
    print("=" * 60)
    from s5_monte_carlo import (run_prediction_by_cluster, estimate_stirpat,
                                backtest_stirpat, estimate_stirpat_panel_fe)
    from shared.utils.emission_processor import load_panel
    import pandas as pd
    
    panel = load_panel()
    
    # 5a: 全样本回测 (2001-2015 training, 2016-2019 evaluation)
    backtest_stirpat(panel, train_end=2015, test_start=2016, test_end=2019)
    
    # 5b: 面板FE稳健性
    estimate_stirpat_panel_fe(panel)
    
    # 5c: Monte Carlo simulation
    cluster_file = OUTPUT_DIR / 'city_clusters.csv'
    if cluster_file.exists():
        city_clusters = pd.read_csv(cluster_file)
        results = run_prediction_by_cluster(panel, city_clusters, n_simulations=100000)
    else:
        print("[提示] 无聚类结果, 执行全局模拟")
        stirpat = estimate_stirpat(panel)
    
    return None


def main():
    parser = argparse.ArgumentParser(description='论文2 分析流程')
    parser.add_argument('--step', type=int, default=0,
                       help='执行特定步骤 (1-5), 0=全部')
    args = parser.parse_args()
    
    if args.step == 0 or args.step == 1:
        raw, std = step1_data_preparation()
    
    if args.step == 0 or args.step == 2:
        if 'raw' not in dir():
            import pandas as pd
            raw = pd.read_csv(OUTPUT_DIR / 'emission_matrix_raw.csv', index_col=0)
            std = pd.read_csv(OUTPUT_DIR / 'emission_matrix_zscore.csv', index_col=0)
        step2_dtw_clustering(raw, std)
    
    if args.step == 0 or args.step == 3:
        if 'raw' not in dir():
            import pandas as pd
            raw = pd.read_csv(OUTPUT_DIR / 'emission_matrix_raw.csv', index_col=0)
        step3_peak_detection(raw)
    
    if args.step == 0 or args.step == 4:
        step4_xgboost_shap()
    
    if args.step == 0 or args.step == 5:
        step5_monte_carlo()
    
    print("\n" + "=" * 60)
    print("论文2 分析完成!")
    print(f"所有结果保存在: {OUTPUT_DIR}")
    print("=" * 60)


if __name__ == '__main__':
    main()
