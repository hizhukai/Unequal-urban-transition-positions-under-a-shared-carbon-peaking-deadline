"""
论文2 模块3: 达峰状态判定
=========================
使用 Mann-Kendall 趋势检验 + Bai-Perron 结构断点检验
为每个城市定量判定达峰状态.

分类:
    - 已达峰: M-K 显著下降 + 断点下行 + 近3年低于峰值5%
    - 即将达峰: 增速显著放缓, 近5年增速<1%
    - 持续上升: 无显著下降趋势

输出:
    - peak_status.csv: city, peak_year, peak_status, mk_trend, mk_p, ...
"""

import sys
import numpy as np
import pandas as pd
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

OUTPUT_DIR = PROJECT_ROOT / 'runtime_output'
OUTPUT_DIR.mkdir(exist_ok=True)


def mann_kendall_test(series: np.ndarray) -> dict:
    """
    Mann-Kendall 趋势检验.
    
    Returns:
        dict: trend, p, z, tau, slope (Sen's slope)
    """
    try:
        import pymannkendall as mk
        result = mk.original_test(series)
        return {
            'trend': result.trend,
            'p': result.p,
            'z': result.z,
            'tau': result.Tau,
            'slope': result.slope,
            'intercept': result.intercept
        }
    except ImportError:
        # 手动实现简化版
        return _mk_manual(series)


def _mk_manual(series: np.ndarray) -> dict:
    """手动实现 Mann-Kendall 检验 (不依赖外部库)."""
    n = len(series)
    s = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            diff = series[j] - series[i]
            if diff > 0:
                s += 1
            elif diff < 0:
                s -= 1
    
    # 方差
    var_s = n * (n - 1) * (2 * n + 5) / 18
    
    # Z 统计量
    if s > 0:
        z = (s - 1) / np.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / np.sqrt(var_s)
    else:
        z = 0
    
    # p 值 (双侧)
    from scipy.stats import norm
    p = 2 * (1 - norm.cdf(abs(z)))
    
    # Kendall's tau
    tau = s / (n * (n - 1) / 2)
    
    # Sen's slope
    slopes = []
    for i in range(n - 1):
        for j in range(i + 1, n):
            if j != i:
                slopes.append((series[j] - series[i]) / (j - i))
    slope = np.median(slopes) if slopes else 0
    
    if p < 0.05:
        trend = 'decreasing' if z < 0 else 'increasing'
    else:
        trend = 'no trend'
    
    return {'trend': trend, 'p': p, 'z': z, 'tau': tau, 
            'slope': slope, 'intercept': 0}


def detect_structural_breaks(series: np.ndarray, 
                              max_breaks: int = 3) -> list:
    """
    检测结构性断点 (简化版 Bai-Perron).
    使用 CUSUM 方法识别排放序列中的转折点.
    
    Returns:
        list of dict: [{position, year_offset, direction, magnitude}, ...]
    """
    n = len(series)
    if n < 6:
        return []
    
    # 计算 CUSUM
    mean_val = np.mean(series)
    cusum = np.cumsum(series - mean_val)
    
    breaks = []
    
    # 寻找 CUSUM 的局部极值点
    for i in range(2, n - 2):
        # 局部最大值 = 上升→下降的转折
        if cusum[i] > cusum[i-1] and cusum[i] > cusum[i+1]:
            if cusum[i] > cusum[i-2] and cusum[i] > cusum[i+2]:
                mag = (np.mean(series[:i+1]) - np.mean(series[i+1:])) / np.std(series)
                breaks.append({
                    'position': i,
                    'direction': 'peak' if mag > 0 else 'trough',
                    'magnitude': abs(mag),
                    'cusum_value': cusum[i]
                })
        # 局部最小值 = 下降→上升的转折
        if cusum[i] < cusum[i-1] and cusum[i] < cusum[i+1]:
            if cusum[i] < cusum[i-2] and cusum[i] < cusum[i+2]:
                mag = (np.mean(series[:i+1]) - np.mean(series[i+1:])) / np.std(series)
                breaks.append({
                    'position': i,
                    'direction': 'trough' if mag < 0 else 'peak',
                    'magnitude': abs(mag),
                    'cusum_value': cusum[i]
                })
    
    # 按重要性排序, 取前 max_breaks 个
    breaks.sort(key=lambda x: x['magnitude'], reverse=True)
    return breaks[:max_breaks]


def classify_peak_status(series: np.ndarray, years: np.ndarray) -> dict:
    """
    对单个城市的排放时序进行达峰状态判定.
    
    Returns:
        dict: {
            peak_status: '已达峰' / '即将达峰' / '持续上升',
            peak_year: 达峰年份 (如有),
            peak_value: 峰值排放量,
            mk_result: M-K 检验结果,
            breaks: 断点列表,
            recent_growth: 近5年年均增长率
        }
    """
    n = len(series)
    
    # 1. M-K 全序列检验
    mk = mann_kendall_test(series)
    
    # 2. 后半段 M-K 检验 (关注近年趋势)
    half = max(n // 2, 5)
    mk_recent = mann_kendall_test(series[-half:])
    
    # 3. 结构断点
    breaks = detect_structural_breaks(series)
    
    # 4. 峰值位置
    peak_idx = np.argmax(series)
    peak_year = int(years[peak_idx])
    peak_value = float(series[peak_idx])
    
    # 5. 近年增长率
    if n >= 5:
        recent = series[-5:]
        recent_growth = (recent[-1] / recent[0]) ** (1/4) - 1 if recent[0] > 0 else 0
    else:
        recent_growth = 0
    
    # 6. 当前值相对峰值
    current_vs_peak = series[-1] / peak_value if peak_value > 0 else 1
    
    # ---- 判定规则 (v3 — 与文献对齐) ----
    #   对齐依据: Shan et al. (2022, 287城) 提供了城市达峰比例的外部对照
    #   本研究采用双轨制: 统计轨(MK检验) + 幅度轨(Shan-like)
    
    # 条件 A: 全序列 M-K 不能为 *强* increasing (tau>0.3 AND p<0.01)
    full_not_strongly_increasing = not (mk['trend'] == 'increasing' and mk['p'] < 0.01 and mk['tau'] > 0.3)
    
    # 条件 B: 后半段 M-K 下降 (放宽至 p<0.10)
    recent_decreasing = (mk_recent['trend'] == 'decreasing' and mk_recent['p'] < 0.10)
    
    # 条件 C: 峰值后子序列 M-K 下降确认 (p<0.15)
    post_peak = series[peak_idx:]
    if len(post_peak) >= 5:
        mk_post = mann_kendall_test(post_peak)
        post_peak_declining = (mk_post['trend'] == 'decreasing' and mk_post['p'] < 0.15)
    else:
        mk_post = {'trend': 'insufficient', 'p': 1.0, 'tau': 0}
        post_peak_declining = False
    
    # 条件 D: 当前排放低于峰值 95%
    well_below_peak = (current_vs_peak < 0.95)
    
    # 条件 E: 峰值不在最近 5 年内
    peak_not_recent = (peak_idx < n - 5)
    
    # 条件 F: 至少有一个结构断点 (可选)
    has_break = (len(breaks) > 0)
    
    # ---- 双轨判定 ----
    
    # 轨道1 (统计轨): A + B + C + D + E
    stat_peaked = (
        full_not_strongly_increasing and
        recent_decreasing and
        post_peak_declining and
        well_below_peak and
        peak_not_recent
    )
    
    # 轨道2 (幅度轨, Guan-like): 从峰值连续下降且幅度显著
    #   条件: 峰后至少5年, 幅度降>10%, 近5年持续下降(增速<0)
    guan_peaked = (
        peak_not_recent and
        current_vs_peak < 0.90 and          # 降幅>10%
        recent_growth < -0.005 and           # 近5年年均下降>0.5%
        len(post_peak) >= 5 and
        post_peak[-1] < post_peak[0] * 0.95  # 峰后末端 < 峰值95%
    )
    
    is_peaked = stat_peaked or guan_peaked
    
    # 即将达峰: 两条路径 (满足任一即可)
    
    # 路径 1 (原条件): 平缓接近峰顶
    #   近 5 年增速 < 1%, 峰值在最近 5 年内, 全序列非强上升
    is_near_peak_flat = (
        not is_peaked and
        abs(recent_growth) < 0.01 and
        peak_idx >= n - 5 and
        not (mk['trend'] == 'increasing' and mk['p'] < 0.01 and mk['tau'] > 0.3)
    )
    
    # 路径 2 (新增): 拐点型 — 历史上升但近年已开始下降
    #   即使全序列 mk=increasing, 但近年出现明确拐点:
    #   (1) 近5年增速 < -1% (已经开始实质性下降)
    #   (2) 当前排放 < 峰值 95%
    #   (3) 峰值在最近 7 年内 (近期刚到峰顶)
    is_near_peak_turning = (
        not is_peaked and
        recent_growth < -0.01 and
        current_vs_peak < 0.95 and
        peak_idx >= n - 7
    )
    
    is_near_peak = is_near_peak_flat or is_near_peak_turning
    
    if is_peaked:
        status = '已达峰'
    elif is_near_peak:
        status = '即将达峰'
    else:
        status = '持续上升'
    
    return {
        'peak_status': status,
        'peak_year': peak_year,
        'peak_value': peak_value,
        'current_value': float(series[-1]),
        'current_vs_peak': current_vs_peak,
        'mk_trend': mk['trend'],
        'mk_p': mk['p'],
        'mk_tau': mk['tau'],
        'mk_slope': mk['slope'],
        'mk_recent_trend': mk_recent['trend'],
        'mk_recent_p': mk_recent['p'],
        'mk_post_peak_trend': mk_post['trend'],
        'mk_post_peak_p': mk_post['p'],
        'recent_growth_rate': recent_growth,
        'n_breaks': len(breaks),
        'break_years': str([int(years[b['position']]) for b in breaks]),
    }


def analyze_all_cities(raw_matrix: pd.DataFrame) -> pd.DataFrame:
    """
    对所有城市执行达峰状态判定.
    
    Args:
        raw_matrix: 城市(行) × 年份(列) 的原始排放矩阵
        
    Returns:
        DataFrame: 每行一个城市的达峰判定结果
    """
    years = np.array(raw_matrix.columns, dtype=int)
    results = []
    
    for city in raw_matrix.index:
        series = raw_matrix.loc[city].values.astype(float)
        
        # 跳过全部为 NaN 的城市
        if np.all(np.isnan(series)):
            continue
        
        result = classify_peak_status(series, years)
        result['city'] = city
        results.append(result)
    
    df = pd.DataFrame(results)
    
    # 统计
    status_counts = df['peak_status'].value_counts()
    print(f"\n[达峰判定] {len(df)} 个城市:")
    for status, count in status_counts.items():
        pct = count / len(df) * 100
        print(f"  {status}: {count} ({pct:.1f}%)")
    
    return df


if __name__ == '__main__':
    from s1_data_preparation import prepare_emission_matrix
    
    # 加载原始排放矩阵
    raw_matrix = prepare_emission_matrix(
        min_completeness=0.80,
        year_range=(2001, 2019),
        source_filter='ceads'
    )
    
    # 达峰判定
    peak_results = analyze_all_cities(raw_matrix)
    
    # 保存
    peak_results.to_csv(OUTPUT_DIR / 'peak_status.csv', 
                        index=False, encoding='utf-8-sig')
    print(f"\n结果已保存到 {OUTPUT_DIR / 'peak_status.csv'}")
    
    # 展示部分结果
    print("\n--- 已达峰城市 (前10) ---")
    peaked = peak_results[peak_results['peak_status'] == '已达峰']
    print(peaked[['city', 'peak_year', 'peak_value', 'current_vs_peak', 
                  'mk_tau']].head(10).to_string(index=False))
