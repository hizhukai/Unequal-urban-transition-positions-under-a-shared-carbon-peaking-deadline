"""
Cluster-trained city-level backtest for Paper 2.

Goal:
1. Fit STIRPAT separately within each cluster using the training period.
2. Apply cluster-specific coefficients to each city's observed covariate path.
3. Evaluate whether city-level deployment of the cluster framework is acceptable.

Outputs:
    - output/revision_experiments/w7_cluster_city_backtest_detail.csv
    - output/revision_experiments/w7_cluster_city_backtest_summary.csv
    - tables/tableS7_cluster_city_backtest.csv
    - figures/diag_cluster_city_backtest.{png,pdf} when --with-figure is used
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from shared.utils.emission_processor import load_panel
from s5_monte_carlo import estimate_stirpat


BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = BASE_DIR / "runtime_output"
TABLE_DIR = BASE_DIR / "tables"
FIG_DIR = BASE_DIR / "figures"
REV_DIR = OUTPUT_DIR / "revision_experiments"

TABLE_DIR.mkdir(exist_ok=True)
FIG_DIR.mkdir(exist_ok=True)
REV_DIR.mkdir(exist_ok=True)

CLUSTER_COLORS = {
    1: "#4393C3",
    2: "#F4A460",
    3: "#2CA02C",
}


def predict_with_cluster_coefs(row: pd.Series, coefs: np.ndarray, has_energy: bool) -> float:
    ln_co2 = (
        coefs[0]
        + coefs[1] * np.log(row["pop_10k"])
        + coefs[2] * np.log(row["gdp_per_capita"])
        + coefs[3] * row["urbanization_rate"]
        + coefs[4] * row["industry2_share"]
    )
    if has_energy and len(coefs) > 5:
        ln_co2 += coefs[5] * np.log(row["energy_consumption"])
    return float(np.exp(ln_co2))


def run_backtest(train_end: int = 2015, test_start: int = 2016, test_end: int = 2019) -> tuple[pd.DataFrame, pd.DataFrame]:
    panel = load_panel()
    clusters = pd.read_csv(OUTPUT_DIR / "city_clusters.csv")
    panel_c = panel.merge(clusters, on="city", how="inner")

    train_panel = panel_c[panel_c["year"] <= train_end].copy()
    test_panel = panel_c[(panel_c["year"] >= test_start) & (panel_c["year"] <= test_end)].copy()

    cluster_models = {}
    for cluster_id in sorted(clusters["cluster"].unique()):
        subset = train_panel[train_panel["cluster"] == cluster_id]
        cluster_models[cluster_id] = estimate_stirpat(subset)

    required = [
        "co2_mt",
        "pop_10k",
        "gdp_per_capita",
        "urbanization_rate",
        "industry2_share",
        "energy_consumption",
    ]
    results = []

    for cluster_id in sorted(clusters["cluster"].unique()):
        model = cluster_models[cluster_id]
        coefs = model["coefs"]
        has_energy = model["has_energy"]
        subset = test_panel[test_panel["cluster"] == cluster_id].copy()
        subset = subset.dropna(subset=required)
        subset = subset[
            (subset["co2_mt"] > 0)
            & (subset["pop_10k"] > 0)
            & (subset["gdp_per_capita"] > 0)
            & (subset["energy_consumption"] > 0)
        ]
        for _, row in subset.iterrows():
            predicted = predict_with_cluster_coefs(row, coefs, has_energy)
            ape = abs(predicted - row["co2_mt"]) / row["co2_mt"] * 100
            results.append({
                "city": row["city"],
                "cluster": cluster_id,
                "year": int(row["year"]),
                "actual": float(row["co2_mt"]),
                "predicted": predicted,
                "error": predicted - row["co2_mt"],
                "APE": ape,
            })

    detail = pd.DataFrame(results)
    if detail.empty:
        raise RuntimeError("No valid backtest observations were produced.")

    city_mape = detail.groupby(["city", "cluster"])["APE"].mean().reset_index(name="city_mape")
    summary_rows = []
    for cluster_id in sorted(detail["cluster"].unique()):
        sub = detail[detail["cluster"] == cluster_id]
        city_sub = city_mape[city_mape["cluster"] == cluster_id]
        spearman = sub[["actual", "predicted"]].corr(method="spearman").iloc[0, 1]
        pearson = sub[["actual", "predicted"]].corr(method="pearson").iloc[0, 1]
        summary_rows.append({
            "cluster": f"C{cluster_id}",
            "cities": int(city_sub["city"].nunique()),
            "predictions": int(len(sub)),
            "median_city_mape": round(float(city_sub["city_mape"].median()), 1),
            "mean_city_mape": round(float(city_sub["city_mape"].mean()), 1),
            "row_mean_ape": round(float(sub["APE"].mean()), 1),
            "spearman_r": round(float(spearman), 3),
            "pearson_r": round(float(pearson), 3),
        })

    global_spearman = detail[["actual", "predicted"]].corr(method="spearman").iloc[0, 1]
    global_pearson = detail[["actual", "predicted"]].corr(method="pearson").iloc[0, 1]
    summary_rows.append({
        "cluster": "Global",
        "cities": int(city_mape["city"].nunique()),
        "predictions": int(len(detail)),
        "median_city_mape": round(float(city_mape["city_mape"].median()), 1),
        "mean_city_mape": round(float(city_mape["city_mape"].mean()), 1),
        "row_mean_ape": round(float(detail["APE"].mean()), 1),
        "spearman_r": round(float(global_spearman), 3),
        "pearson_r": round(float(global_pearson), 3),
    })

    summary = pd.DataFrame(summary_rows)
    return detail, summary


def make_figure(detail: pd.DataFrame) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.5))

    ax = axes[0]
    for cluster_id in sorted(detail["cluster"].unique()):
        sub = detail[detail["cluster"] == cluster_id]
        ax.scatter(
            sub["actual"],
            sub["predicted"],
            s=18,
            alpha=0.65,
            color=CLUSTER_COLORS[cluster_id],
            label=f"C{cluster_id}",
        )
    max_val = float(max(detail["actual"].max(), detail["predicted"].max()))
    ax.plot([0, max_val], [0, max_val], linestyle="--", color="#666666", linewidth=1.0)
    ax.set_xlabel("Actual CO2 (Mt)")
    ax.set_ylabel("Predicted CO2 (Mt)")
    ax.set_title("Cluster-trained city-level backtest")
    ax.legend(frameon=False, fontsize=8)

    ax = axes[1]
    city_mape = detail.groupby(["city", "cluster"])["APE"].mean().reset_index(name="city_mape")
    box_data = [
        city_mape[city_mape["cluster"] == cluster_id]["city_mape"].to_numpy(dtype=float)
        for cluster_id in sorted(city_mape["cluster"].unique())
    ]
    bp = ax.boxplot(box_data, patch_artist=True, labels=[f"C{i}" for i in sorted(city_mape["cluster"].unique())])
    for patch, cluster_id in zip(bp["boxes"], sorted(city_mape["cluster"].unique())):
        patch.set_facecolor(CLUSTER_COLORS[cluster_id])
        patch.set_alpha(0.65)
    ax.set_ylabel("City-level MAPE (%)")
    ax.set_title("Backtest error by cluster")

    fig.tight_layout()
    fig.savefig(FIG_DIR / "diag_cluster_city_backtest.png", dpi=600, bbox_inches="tight")
    fig.savefig(FIG_DIR / "diag_cluster_city_backtest.pdf", bbox_inches="tight")
    plt.close(fig)


def main(make_fig: bool = False) -> None:
    print("=" * 70)
    print("W7: cluster-trained city-level backtest")
    print("=" * 70)

    detail, summary = run_backtest()
    print(summary.to_string(index=False))

    detail.to_csv(REV_DIR / "w7_cluster_city_backtest_detail.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(REV_DIR / "w7_cluster_city_backtest_summary.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(TABLE_DIR / "tableS7_cluster_city_backtest.csv", index=False, encoding="utf-8-sig")

    if make_fig:
        make_figure(detail)

    print(f"\nSaved:")
    print(f"  - {REV_DIR / 'w7_cluster_city_backtest_detail.csv'}")
    print(f"  - {TABLE_DIR / 'tableS7_cluster_city_backtest.csv'}")
    if make_fig:
        print(f"  - {FIG_DIR / 'diag_cluster_city_backtest.png'}")


if __name__ == "__main__":
    main(make_fig="--with-figure" in sys.argv)
