"""
论文2 模块2: DTW 时序聚类
=========================
基于 Dynamic Time Warping (DTW) 距离的城市碳排放轨迹聚类.

方法:
    1. DTW 距离矩阵计算 (tslearn)
    2. 层次聚类 (Ward's method)
    3. k-means + Euclidean 作为对比基线
    4. 最优聚类数选择: 轮廓系数 + Calinski-Harabasz

输出:
    - 每个城市的聚类标签
    - 各聚类的平均轨迹 + 95% 包络
    - 聚类评价指标对比表
"""

import sys
import numpy as np
import pandas as pd
from pathlib import Path
from scipy.cluster.hierarchy import linkage, fcluster, dendrogram
from scipy.spatial.distance import squareform
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, calinski_harabasz_score
from sklearn.preprocessing import StandardScaler

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

OUTPUT_DIR = PROJECT_ROOT / 'runtime_output'
OUTPUT_DIR.mkdir(exist_ok=True)


def compute_dtw_distance_matrix(matrix: np.ndarray,
                                 use_fast: bool = True) -> np.ndarray:
    """
    计算 DTW 距离矩阵.
    
    Args:
        matrix: (n_cities, n_years) 标准化排放矩阵
        use_fast: 使用 dtw-python 的快速实现
        
    Returns:
        (n_cities, n_cities) 对称距离矩阵
    """
    n = matrix.shape[0]
    dist_matrix = np.zeros((n, n))
    
    try:
        from dtaidistance import dtw as dtw_fast
        print(f"[DTW] 使用 dtaidistance 快速实现 ({n} 城市)")
        
        # dtaidistance 可以批量计算
        dist_array = dtw_fast.distance_matrix(matrix.astype(np.double))
        dist_matrix = np.array(dist_array)
        
    except ImportError:
        try:
            from tslearn.metrics import dtw as tslearn_dtw
            print(f"[DTW] 使用 tslearn ({n} 城市, 可能较慢)")
            
            total = n * (n - 1) // 2
            count = 0
            for i in range(n):
                for j in range(i + 1, n):
                    d = tslearn_dtw(matrix[i], matrix[j])
                    dist_matrix[i, j] = d
                    dist_matrix[j, i] = d
                    count += 1
                    if count % 5000 == 0:
                        print(f"  进度: {count}/{total} ({count/total:.0%})")
                        
        except ImportError:
            from dtw import dtw as dtw_classic
            print(f"[DTW] 使用 dtw-python ({n} 城市)")
            
            total = n * (n - 1) // 2
            count = 0
            for i in range(n):
                for j in range(i + 1, n):
                    alignment = dtw_classic(matrix[i], matrix[j])
                    d = alignment.distance
                    dist_matrix[i, j] = d
                    dist_matrix[j, i] = d
                    count += 1
                    if count % 5000 == 0:
                        print(f"  进度: {count}/{total} ({count/total:.0%})")
    
    print(f"[DTW] 距离矩阵计算完成: {n}×{n}")
    return dist_matrix


def hierarchical_clustering(dist_matrix: np.ndarray,
                            k_range: range = range(3, 9)) -> dict:
    """
    层次聚类 + 最优 k 选择.
    尝试多种 linkage (ward, complete, average) 以适配 DTW 非欧距离.
    
    Returns:
        dict: {
            'linkage': linkage 矩阵,
            'best_k': 最优聚类数,
            'labels': {k: labels},
            'metrics': DataFrame (k, silhouette, calinski_harabasz),
            'method': 最优链接方法
        }
    """
    condensed = squareform(dist_matrix)
    
    best_overall_sil = -1
    best_method = 'ward'
    best_Z = None
    best_labels_dict = None
    best_results = None
    best_k_overall = 3
    
    for method in ['ward', 'complete', 'average']:
        Z = linkage(condensed, method=method)
        
        results = []
        labels_dict = {}
        
        for k in k_range:
            labels = fcluster(Z, k, criterion='maxclust')
            labels_dict[k] = labels
            
            # 检查聚类平衡性: 最小聚类 >= 10 城市
            min_cluster_size = min(np.bincount(labels)[1:])  # bincount从0开始, labels从1
            if min_cluster_size < 10:
                sil = -1  # 惩罚不平衡聚类
                ch = 0
                results.append({'k': k, 'silhouette': sil, 'calinski_harabasz': ch})
                continue
            
            sil = silhouette_score(dist_matrix, labels, metric='precomputed')
            ch = calinski_harabasz_score(dist_matrix, labels)
            results.append({'k': k, 'silhouette': sil, 'calinski_harabasz': ch})
        
        df = pd.DataFrame(results)
        best_idx = df['silhouette'].idxmax()
        best_k = int(df.loc[best_idx, 'k'])
        best_sil = df.loc[best_idx, 'silhouette']
        
        balanced = "✅" if best_sil > 0 else "❌ 不平衡"
        print(f"  [{method}] 最优 k={best_k}, Silhouette={best_sil:.3f} {balanced}")
        
        if best_sil > best_overall_sil:
            best_overall_sil = best_sil
            best_method = method
            best_Z = Z
            best_labels_dict = labels_dict
            best_results = df
            best_k_overall = best_k
    
    print(f"\n  → 选择 {best_method} 链接, k={best_k_overall}, "
          f"Silhouette={best_overall_sil:.3f}")
    
    for _, row in best_results.iterrows():
        print(f"  k={int(row['k'])}: Silhouette={row['silhouette']:.3f}, "
              f"CH={row['calinski_harabasz']:.1f}")
    
    print(f"[层次聚类] 最优 k = {best_k_overall} ({best_method}, "
          f"Silhouette 最高)")

    return {
        'linkage': best_Z,
        'best_k': best_k_overall,
        'labels': best_labels_dict,
        'metrics': best_results,
        'method': best_method,
    }


def kmeans_euclidean(matrix: np.ndarray,
                     k_range: range = range(3, 9)) -> dict:
    """
    K-means + 欧氏距离 (对比基线).
    """
    results = []
    labels_dict = {}
    
    for k in k_range:
        km = KMeans(n_clusters=k, n_init=50, random_state=42, max_iter=300)
        labels = km.fit_predict(matrix)
        labels_dict[k] = labels
        
        sil = silhouette_score(matrix, labels, metric='euclidean')
        ch = calinski_harabasz_score(matrix, labels)
        
        results.append({'k': k, 'silhouette': sil, 'calinski_harabasz': ch})
    
    metrics = pd.DataFrame(results)
    best_k = metrics.loc[metrics['silhouette'].idxmax(), 'k']
    
    print(f"[K-means] 最优 k = {best_k} (Silhouette 最高)")
    
    return {
        'best_k': int(best_k),
        'labels': labels_dict,
        'metrics': metrics
    }


def compute_cluster_profiles(raw_matrix: pd.DataFrame,
                             labels: np.ndarray) -> pd.DataFrame:
    """
    计算各聚类的平均轨迹和 95% 包络.
    
    Returns:
        DataFrame: 列 = [cluster, year, mean, lower_95, upper_95, n_cities]
    """
    profiles = []
    cities = raw_matrix.index
    years = raw_matrix.columns
    
    for cluster_id in sorted(np.unique(labels)):
        mask = labels == cluster_id
        cluster_data = raw_matrix.values[mask]
        
        for j, year in enumerate(years):
            vals = cluster_data[:, j]
            profiles.append({
                'cluster': int(cluster_id),
                'year': int(year),
                'mean': np.mean(vals),
                'median': np.median(vals),
                'lower_95': np.percentile(vals, 2.5),
                'upper_95': np.percentile(vals, 97.5),
                'std': np.std(vals),
                'n_cities': int(mask.sum())
            })
    
    return pd.DataFrame(profiles)


def run_full_analysis(raw_matrix: pd.DataFrame, std_matrix: pd.DataFrame,
                      k_range: range = range(3, 9)) -> dict:
    """
    执行完整的 DTW 聚类分析流程.
    
    Returns:
        dict: 包含所有中间结果
    """
    values = std_matrix.values
    
    print("=" * 60)
    print("DTW 聚类分析")
    print("=" * 60)
    
    # 1. DTW 距离矩阵
    print("\n--- Step 1: DTW 距离矩阵 ---")
    dtw_dist = compute_dtw_distance_matrix(values)
    
    # 2. 层次聚类 (DTW)
    print("\n--- Step 2: 层次聚类 (DTW + Ward) ---")
    hc_result = hierarchical_clustering(dtw_dist, k_range)
    best_k = hc_result['best_k']
    
    # 3. K-means 对比
    print("\n--- Step 3: K-means 对比基线 ---")
    km_result = kmeans_euclidean(values, k_range)
    
    # 4. 聚类结果
    best_labels = hc_result['labels'][best_k]
    
    # 6. 聚类 profiles
    print("\n--- Step 5: 聚类轨迹 profiles ---")
    profiles = compute_cluster_profiles(raw_matrix, best_labels)
    
    # 7. 城市-聚类映射
    city_clusters = pd.DataFrame({
        'city': std_matrix.index,
        'cluster': best_labels
    })
    
    # 输出统计
    print("\n--- 聚类结果统计 ---")
    for c in sorted(np.unique(best_labels)):
        cities_in_cluster = city_clusters[city_clusters['cluster'] == c]['city'].tolist()
        print(f"  类{c} ({len(cities_in_cluster)} 城市): "
              f"{', '.join(cities_in_cluster[:5])}{'...' if len(cities_in_cluster) > 5 else ''}")
    
    # 保存结果
    city_clusters.to_csv(OUTPUT_DIR / 'city_clusters.csv', 
                         index=False, encoding='utf-8-sig')
    profiles.to_csv(OUTPUT_DIR / 'cluster_profiles.csv',
                    index=False, encoding='utf-8-sig')
    
    # 方法对比表
    comparison = hc_result['metrics'].rename(
        columns={'silhouette': 'DTW_silhouette', 'calinski_harabasz': 'DTW_CH'}
    ).merge(
        km_result['metrics'].rename(
            columns={'silhouette': 'Eucl_silhouette', 'calinski_harabasz': 'Eucl_CH'}
        ), on='k'
    )
    comparison.to_csv(OUTPUT_DIR / 'clustering_comparison.csv', index=False)
    print(f"\n方法对比:")
    print(comparison.to_string(index=False))
    
    # 距离矩阵存储
    np.save(OUTPUT_DIR / 'dtw_distance_matrix.npy', dtw_dist)
    
    print(f"\n结果已保存到 {OUTPUT_DIR}")
    
    return {
        'dtw_dist': dtw_dist,
        'hc_result': hc_result,
        'km_result': km_result,
        'best_k': best_k,
        'best_labels': best_labels,
        'city_clusters': city_clusters,
        'profiles': profiles,
        'comparison': comparison,
    }


if __name__ == '__main__':
    from s1_data_preparation import prepare_emission_matrix, zscore_normalize
    
    # 准备数据
    raw_matrix = prepare_emission_matrix(
        min_completeness=0.80,
        year_range=(2001, 2019),
        source_filter='ceads'
    )
    std_matrix = zscore_normalize(raw_matrix)
    
    # 执行完整分析
    results = run_full_analysis(raw_matrix, std_matrix, k_range=range(3, 9))
    
    print(f"\n{'='*60}")
    print(f"分析完成! 最优聚类: k={results['best_k']}")
    print(f"{'='*60}")
