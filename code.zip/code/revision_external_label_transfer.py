"""
External label-transfer validation for Paper 2.

Goal:
1. Keep the 112-city DTW typology fixed.
2. Transfer C1/C2/C3 labels to a larger emission-complete sample by nearest medoid.
3. Test whether headline pathway claims persist outside the data-rich core sample.

Outputs:
    - output/revision_experiments/w6_external_label_transfer_assignments.csv
    - output/revision_experiments/w6_external_label_transfer_summary.csv
    - tables/tableS2_external_label_transfer_validation.csv
    - figures/figS1cd_external_label_transfer_validation.{png,pdf} via render_figS1cd_external_label_transfer.py
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from s1_data_preparation import prepare_emission_matrix, zscore_normalize
from s3_peak_detection import analyze_all_cities


BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = BASE_DIR / "runtime_output"
TABLE_DIR = BASE_DIR / "tables"
FIG_DIR = BASE_DIR / "figures"
REV_DIR = OUTPUT_DIR / "revision_experiments"

TABLE_DIR.mkdir(exist_ok=True)
FIG_DIR.mkdir(exist_ok=True)
REV_DIR.mkdir(exist_ok=True)

CLUSTER_COLORS = {
    1: "#4393C3",
    2: "#F4A460",
    3: "#2CA02C",
}
STATUS_ORDER = ["已达峰", "即将达峰", "持续上升"]
STATUS_COLORS = {
    "已达峰": "#4393C3",
    "即将达峰": "#FF7F0E",
    "持续上升": "#999999",
}


def _dtw_distance(series_a: np.ndarray, series_b: np.ndarray) -> float:
    try:
        from dtaidistance import dtw as dtw_fast
        return float(dtw_fast.distance(series_a.astype(np.double), series_b.astype(np.double)))
    except ImportError:
        try:
            from tslearn.metrics import dtw as tslearn_dtw
            return float(tslearn_dtw(series_a, series_b))
        except ImportError:
            from dtw import dtw as dtw_classic
            return float(dtw_classic(series_a, series_b).distance)


def compute_cluster_medoids(std_base: pd.DataFrame, clusters: pd.DataFrame) -> pd.DataFrame:
    rows = []
    years = std_base.columns.tolist()
    for cluster_id in sorted(clusters["cluster"].unique()):
        cities = clusters.loc[clusters["cluster"] == cluster_id, "city"].tolist()
        subset = std_base.loc[cities]
        values = subset.values
        n = len(subset)
        dist = np.zeros((n, n), dtype=float)
        for i in range(n):
            for j in range(i + 1, n):
                d = _dtw_distance(values[i], values[j])
                dist[i, j] = d
                dist[j, i] = d
        medoid_idx = int(np.argmin(dist.sum(axis=1)))
        medoid_city = subset.index[medoid_idx]
        rows.append({
            "cluster": cluster_id,
            "medoid_city": medoid_city,
            "n_cities": n,
            **{str(year): subset.loc[medoid_city, str(year)] for year in years},
        })
    return pd.DataFrame(rows)


def assign_by_nearest_medoid(std_full: pd.DataFrame, medoids: pd.DataFrame) -> pd.DataFrame:
    years = [c for c in medoids.columns if c.isdigit()]
    medoid_series = {
        int(row["cluster"]): row[years].to_numpy(dtype=float)
        for _, row in medoids.iterrows()
    }
    records = []
    for city, row in std_full.iterrows():
        series = row.to_numpy(dtype=float)
        dist_map = {
            cluster_id: _dtw_distance(series, medoid_series[cluster_id])
            for cluster_id in medoid_series
        }
        assigned_cluster = min(dist_map, key=dist_map.get)
        records.append({
            "city": city,
            "assigned_cluster": assigned_cluster,
            "nearest_dtw_distance": dist_map[assigned_cluster],
            "dist_to_c1": dist_map.get(1, np.nan),
            "dist_to_c2": dist_map.get(2, np.nan),
            "dist_to_c3": dist_map.get(3, np.nan),
        })
    return pd.DataFrame(records)


def build_summary(
    assignments: pd.DataFrame,
    peak_status: pd.DataFrame,
    raw_matrix: pd.DataFrame,
    sample_name: str,
) -> pd.DataFrame:
    col_2019 = 2019 if 2019 in raw_matrix.columns else "2019"
    col_2001 = 2001 if 2001 in raw_matrix.columns else "2001"
    base_2019 = raw_matrix[col_2019]
    base_2001 = raw_matrix[col_2001]
    merged = assignments.merge(peak_status[["city", "peak_status", "current_vs_peak"]], on="city", how="left")
    merged["sample"] = sample_name
    merged["co2_2019"] = merged["city"].map(base_2019.to_dict())
    merged["co2_change_pct_2001_2019"] = (
        (merged["city"].map(base_2019.to_dict()) - merged["city"].map(base_2001.to_dict()))
        / merged["city"].map(base_2001.to_dict()).replace(0, np.nan)
        * 100
    )

    rows = []
    sample_df = merged[merged["sample"] == sample_name]
    for cluster_id in sorted(sample_df["assigned_cluster"].dropna().unique()):
        sub = sample_df[sample_df["assigned_cluster"] == cluster_id]
        status_share = sub["peak_status"].value_counts(normalize=True)
        rows.append({
            "sample": sample_name,
            "cluster_like": f"C{int(cluster_id)}",
            "n_cities": int(len(sub)),
            "median_co2_2019_mt": round(float(sub["co2_2019"].median()), 2),
            "median_change_pct_2001_2019": round(float(sub["co2_change_pct_2001_2019"].median()), 1),
            "median_current_vs_peak": round(float(sub["current_vs_peak"].median()), 3),
            "share_peaked": round(float(status_share.get("已达峰", 0.0)), 3),
            "share_near_peak": round(float(status_share.get("即将达峰", 0.0)), 3),
            "share_rising": round(float(status_share.get("持续上升", 0.0)), 3),
        })
    return pd.DataFrame(rows)


def make_figure(
    std_full: pd.DataFrame,
    summary: pd.DataFrame,
    assignments: pd.DataFrame,
    baseline_cities: set,
    medoids: pd.DataFrame,
) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    years = [int(c) for c in std_full.columns]
    merged = assignments.copy()
    std_plot = std_full.copy()
    std_plot["city"] = std_plot.index
    std_plot = std_plot.merge(merged[["city", "assigned_cluster", "sample"]], on="city", how="left")

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.5))

    ax = axes[0]
    for cluster_id in [1, 2, 3]:
        for sample_name, linestyle, alpha in [
            ("baseline_112", "-", 1.0),
            ("external_70", "--", 0.9),
            ("external_60", ":", 0.9),
        ]:
            sub = std_plot[
                (std_plot["assigned_cluster"] == cluster_id)
                & (std_plot["sample"] == sample_name)
            ]
            if sub.empty:
                continue
            mean_line = sub[[str(y) for y in years]].mean(axis=0).to_numpy(dtype=float)
            label = f"C{cluster_id} {sample_name.replace('_', ' ')}"
            ax.plot(years, mean_line, linestyle=linestyle, linewidth=2.0,
                    color=CLUSTER_COLORS[cluster_id], alpha=alpha, label=label)
    ax.set_title("Transferred pathway shapes")
    ax.set_xlabel("Year")
    ax.set_ylabel("Z-score normalized CO2")
    ax.axhline(0, color="#BBBBBB", linestyle=":", linewidth=0.8)
    ax.legend(fontsize=7, ncol=2, frameon=False)

    ax = axes[1]
    plot_df = summary.copy()
    x_labels = []
    xpos = np.arange(len(plot_df))
    bottom = np.zeros(len(plot_df))
    for status in STATUS_ORDER:
        values = []
        for _, row in plot_df.iterrows():
            col = {
                "已达峰": "share_peaked",
                "即将达峰": "share_near_peak",
                "持续上升": "share_rising",
            }[status]
            values.append(row[col])
            x_labels.append(f"{row['cluster_like']}\n{row['sample'].replace('_', ' ')}")
        ax.bar(xpos, values, bottom=bottom, color=STATUS_COLORS[status], width=0.72, label=status)
        bottom += np.asarray(values)
    ax.set_ylim(0, 1)
    ax.set_ylabel("Share of cities")
    ax.set_xticks(xpos)
    ax.set_xticklabels([f"{r.cluster_like}\n{r.sample.replace('_', ' ')}" for r in plot_df.itertuples()], fontsize=8)
    ax.set_title("Peaking-status composition after label transfer")
    ax.legend(fontsize=7, frameon=False, loc="upper right")

    fig.tight_layout()
    fig.savefig(FIG_DIR / "figS1cd_external_label_transfer_validation_matplotlib_preview.png", dpi=600, bbox_inches="tight")
    fig.savefig(FIG_DIR / "figS1cd_external_label_transfer_validation_matplotlib_preview.pdf", bbox_inches="tight")
    plt.close(fig)


def main(make_fig: bool = False) -> None:
    print("=" * 70)
    print("W6: external label-transfer validation")
    print("=" * 70)

    baseline_raw = pd.read_csv(OUTPUT_DIR / "emission_matrix_raw.csv", index_col=0)
    baseline_std = pd.read_csv(OUTPUT_DIR / "emission_matrix_zscore.csv", index_col=0)
    clusters = pd.read_csv(OUTPUT_DIR / "city_clusters.csv")
    baseline_cities = set(baseline_raw.index)
    baseline_peak = pd.read_csv(OUTPUT_DIR / "peak_status.csv")

    medoids = compute_cluster_medoids(baseline_std, clusters)
    baseline_assign = assign_by_nearest_medoid(baseline_std, medoids)
    baseline_assign["is_baseline_city"] = True
    baseline_assign["sample"] = "baseline_112"

    baseline_eval = baseline_assign.merge(clusters, on="city", how="left")
    transfer_accuracy = (baseline_eval["assigned_cluster"] == baseline_eval["cluster"]).mean()
    print(f"[transfer] baseline nearest-medoid recovery accuracy = {transfer_accuracy:.1%}")

    baseline_summary_assign = clusters.rename(columns={"cluster": "assigned_cluster"}).copy()
    baseline_summary_assign["sample"] = "baseline_112"
    baseline_assign_out = baseline_assign.merge(
        clusters.rename(columns={"cluster": "original_cluster"}),
        on="city",
        how="left",
    )

    summary_parts = [
        build_summary(baseline_summary_assign, baseline_peak, baseline_raw, "baseline_112")
    ]
    assignment_parts = [
        baseline_assign_out.merge(
            baseline_peak[["city", "peak_status", "current_vs_peak", "peak_year"]],
            on="city",
            how="left",
        )
    ]

    std_plot_parts = [baseline_std.assign(city=baseline_std.index, sample="baseline_112")]

    for threshold in [0.70, 0.60]:
        raw_pool = prepare_emission_matrix(
            min_completeness=threshold,
            year_range=(2001, 2019),
            source_filter="ceads",
        )
        std_pool = zscore_normalize(raw_pool)
        external_std = std_pool.loc[~std_pool.index.isin(baseline_cities)]
        if external_std.empty:
            continue
        peak_pool = analyze_all_cities(raw_pool)
        sample_name = f"external_{int(threshold * 100)}"
        ext_assign = assign_by_nearest_medoid(external_std, medoids)
        ext_assign["sample"] = sample_name

        summary_parts.append(build_summary(ext_assign, peak_pool, raw_pool, sample_name))
        assignment_parts.append(
            ext_assign.merge(
                peak_pool[["city", "peak_status", "current_vs_peak", "peak_year"]],
                on="city",
                how="left",
            )
        )
        std_plot_parts.append(external_std.assign(city=external_std.index, sample=sample_name))

    summary = pd.concat(summary_parts, ignore_index=True)
    assignments_out = pd.concat(assignment_parts, ignore_index=True)
    print("\n[summary]")
    print(summary.to_string(index=False))

    assignments_out.to_csv(REV_DIR / "w6_external_label_transfer_assignments.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(REV_DIR / "w6_external_label_transfer_summary.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(TABLE_DIR / "tableS2_external_label_transfer_validation.csv", index=False, encoding="utf-8-sig")

    if make_fig:
        std_plot = pd.concat(std_plot_parts, ignore_index=True)
        std_plot = std_plot.merge(assignments_out[["city", "assigned_cluster", "sample"]], on=["city", "sample"], how="left")
        make_figure(
            std_plot.drop(columns=["city", "assigned_cluster", "sample"], errors="ignore"),
            summary,
            assignments_out[["city", "assigned_cluster", "sample"]],
            baseline_cities,
            medoids,
        )

    note_path = REV_DIR / "w6_external_label_transfer_notes.txt"
    note_path.write_text(
        "\n".join([
            f"Baseline nearest-medoid recovery accuracy: {transfer_accuracy:.4f}",
            f"Baseline sample size: {len(baseline_cities)}",
            "External sample sizes by threshold: "
            + ", ".join(
                f"{name}={int((assignments_out['sample'] == name).sum())}"
                for name in ["external_70", "external_60"]
                if name in assignments_out["sample"].unique()
            ),
            f"Medoid cities: " + ", ".join(
                f"C{int(r.cluster)}={r.medoid_city}" for r in medoids.itertuples()
            ),
        ]),
        encoding="utf-8",
    )
    print(f"\nSaved:")
    print(f"  - {REV_DIR / 'w6_external_label_transfer_assignments.csv'}")
    print(f"  - {TABLE_DIR / 'tableS2_external_label_transfer_validation.csv'}")
    if make_fig:
        print(f"  - {FIG_DIR / 'figS1cd_external_label_transfer_validation_matplotlib_preview.png'}")


if __name__ == "__main__":
    main(make_fig="--with-figure" in sys.argv)
