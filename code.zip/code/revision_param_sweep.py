"""
参数连续扫描: 逐一变化5个参数,其余固定BAU,画模拟转折份额曲线
Fig. S5 — Single-parameter continuous sensitivity analysis
"""
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from sklearn.linear_model import LinearRegression

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from shared.utils.emission_processor import load_panel
from s5_monte_carlo import design_scenarios, estimate_stirpat

OUTPUT_DIR = PROJECT_ROOT / 'runtime_output'
FIG_DIR = Path(__file__).parent.parent / 'figures'
FIG_DIR.mkdir(exist_ok=True)

N_SIM = 20000  # 每个参数值的模拟次数(扫描用,比正式少)


def fast_mc_turning_share(coefs, sigma, base_values, scenario, n_sim=N_SIM):
    """Return the share of simulated trajectories turning by 2030."""
    turning_trajectories_by_2030 = 0
    for _ in range(n_sim):
        c = coefs + np.random.normal(0, abs(coefs) * 0.1)
        pop, gdp = base_values['pop'], base_values['gdp_pc']
        urb, ind, eng = base_values['urban'], base_values['industry2'], base_values['energy']
        ems = []
        for yr in range(2020, 2036):
            pop *= (1 + scenario['pop_growth'])
            gdp *= (1 + scenario['gdp_pc_growth'])
            urb = min(1.0, urb + scenario['urban_change'])
            ind = max(0.05, ind + scenario['industry2_change'])
            eng *= (1 + scenario.get('energy_change', 0.01))
            eng = max(1.0, eng)
            ln_co2 = (c[0] + c[1]*np.log(pop) + c[2]*np.log(gdp) +
                      c[3]*urb + c[4]*ind + c[5]*np.log(eng))
            ln_co2 += np.random.normal(0, sigma * 0.5)
            ems.append(np.exp(ln_co2))
        pi = np.argmax(ems)
        if pi < len(ems) - 2 and 2020 + pi <= 2030:
            turning_trajectories_by_2030 += 1
    return turning_trajectories_by_2030 / n_sim


def get_cluster_setup(panel, clusters, cluster_id):
    """获取聚类的STIRPAT系数、基期值和BAU情景"""
    panel_c = panel.merge(clusters, on='city', how='inner')
    subset = panel_c[panel_c['cluster'] == cluster_id]

    stirpat = estimate_stirpat(subset)
    coefs = stirpat['coefs']
    sigma = stirpat['sigma']

    # 基期值
    base_year = subset[subset['year'] == subset['year'].max()]
    base_values = {
        'pop': base_year['pop_10k'].mean(),
        'gdp_pc': base_year['gdp_per_capita'].mean(),
        'urban': base_year['urbanization_rate'].mean(),
        'industry2': base_year['industry2_share'].mean(),
        'energy': base_year['energy_consumption'].mean(),
    }
    defaults = {'pop': 50, 'gdp_pc': 60000, 'urban': 0.6, 'industry2': 0.4, 'energy': 100}
    for k, v in base_values.items():
        if np.isnan(v):
            base_values[k] = defaults[k]

    # 聚类画像 -> BAU情景
    early = subset[subset['year'] <= 2010]
    late = subset[subset['year'] >= 2015]
    early_co2 = early.groupby('city')['co2_mt'].mean().mean() if len(early) > 0 else 1
    late_co2 = late.groupby('city')['co2_mt'].mean().mean() if len(late) > 0 else 1
    co2_change = (late_co2 - early_co2) / max(early_co2, 0.001)
    if co2_change < -0.05: trend = 'declining'
    elif co2_change > 0.2: trend = 'rising'
    else: trend = 'stable'

    latest = subset[subset['year'] == subset['year'].max()]
    cluster_profile = {
        'trend': trend,
        'avg_industry2': latest['industry2_share'].mean(),
        'avg_urban': latest['urbanization_rate'].mean(),
        'avg_gdp_pc': latest['gdp_per_capita'].mean(),
    }
    scenarios = design_scenarios(cluster_profile)

    return coefs, sigma, base_values, scenarios


def run_sweep():
    panel = load_panel()
    clusters = pd.read_csv(OUTPUT_DIR / 'city_clusters.csv')

    # 5个参数的扫描范围和标签
    params = [
        ('pop_growth',       np.linspace(-0.005, 0.010, 16), 'Population growth rate (%/yr)',
         lambda x: x*100),
        ('gdp_pc_growth',    np.linspace(0.02, 0.10, 17),    'GDP per capita growth rate (%/yr)',
         lambda x: x*100),
        ('urban_change',     np.linspace(0.002, 0.016, 15),  'Urbanization rate change (pp/yr)',
         lambda x: x*100),
        ('industry2_change', np.linspace(-0.020, 0.005, 16), 'Secondary industry share change (pp/yr)',
         lambda x: x*100),
        ('energy_change',    np.linspace(-0.04, 0.06, 21),   'Energy consumption change (%/yr)',
         lambda x: x*100),
    ]

    cluster_names = {1: 'C1 (Service-led)', 2: 'C2 (Industrial transition)', 3: 'C3 (High-growth)'}
    cluster_colors = {1: '#2196F3', 2: '#FF5722', 3: '#4CAF50'}

    # 获取各聚类模型
    setups = {}
    for cid in [1, 2, 3]:
        setups[cid] = get_cluster_setup(panel, clusters, cid)
        print(f"C{cid} setup done")

    # 扫描
    all_results = []
    for param_key, sweep_vals, label, fmt_fn in params:
        print(f"\n{'='*50}")
        print(f"Sweeping: {param_key}")
        for cid in [1, 2, 3]:
            coefs, sigma, base_values, scenarios = setups[cid]
            bau = scenarios['BAU'].copy()

            for val in sweep_vals:
                scenario = bau.copy()
                scenario[param_key] = val
                turning_share = fast_mc_turning_share(coefs, sigma, base_values, scenario)
                all_results.append({
                    'param': param_key,
                    'param_value': val,
                    'param_display': fmt_fn(val),
                    'cluster': cid,
                    'simulated_turning_share_by_2030': turning_share,
                })
                print(f"  C{cid} {param_key}={val:+.4f} -> simulated share={turning_share:.1%}")

    df = pd.DataFrame(all_results)
    df.to_csv(OUTPUT_DIR / 'revision_experiments' / 'param_sweep_results.csv',
              index=False, encoding='utf-8-sig')

    # ---- 绘图: 2行 (3+2), 统一尺寸+坐标, Arial可编辑 ----
    import matplotlib
    matplotlib.rcParams['font.family'] = 'Arial'
    matplotlib.rcParams['pdf.fonttype'] = 42   # TrueType → Adobe可编辑
    matplotlib.rcParams['ps.fonttype'] = 42

    # 统一Y轴范围
    y_min = df['simulated_turning_share_by_2030'].min() * 100 - 3
    y_max = df['simulated_turning_share_by_2030'].max() * 100 + 3

    from matplotlib.gridspec import GridSpec
    fig = plt.figure(figsize=(14, 9))
    gs = GridSpec(2, 6, figure=fig, hspace=0.35, wspace=0.10,
                  left=0.08, right=0.96, bottom=0.08, top=0.95)
    # 第一行: 3个等宽子图 (各占2列)
    ax1 = fig.add_subplot(gs[0, 0:2])
    ax2 = fig.add_subplot(gs[0, 2:4])
    ax3 = fig.add_subplot(gs[0, 4:6])
    # 第二行: 2个等宽子图居中 (各占2列, 左右各留1列)
    ax4 = fig.add_subplot(gs[1, 1:3])
    ax5 = fig.add_subplot(gs[1, 3:5])
    axes = [ax1, ax2, ax3, ax4, ax5]

    for ax_i, (param_key, sweep_vals, label, fmt_fn) in enumerate(params):
        ax = axes[ax_i]
        sub = df[df['param'] == param_key]

        for cid in [1, 2, 3]:
            cdata = sub[sub['cluster'] == cid].sort_values('param_display')
            ax.plot(cdata['param_display'], cdata['simulated_turning_share_by_2030'] * 100,
                    color=cluster_colors[cid], linewidth=2,
                    marker='o', markersize=3, label=cluster_names[cid])

        # BAU竖线 (用C2的BAU值作为参考)
        bau_val = fmt_fn(setups[2][3]['BAU'][param_key])
        ax.axvline(bau_val, color='gray', linestyle='--', alpha=0.5,
                   linewidth=0.8, label='BAU (C2)' if ax_i == 0 else None)

        ax.set_ylim(y_min, y_max)
        ax.set_xlabel(label, fontsize=9)
        ax.set_title(f'({chr(97+ax_i)})', fontsize=11, fontweight='bold', loc='left')
        ax.grid(True, alpha=0.3)
        ax.tick_params(labelsize=8)

        if ax_i in (0, 3):
            ax.set_ylabel('Simulated share turning by 2030 (%)', fontsize=10)
        else:
            ax.set_yticklabels([])

    axes[0].legend(loc='lower left', fontsize=7.5, framealpha=0.9)

    # 保存 PNG + PDF
    for ext in ['png', 'pdf']:
        out_path = FIG_DIR / f'figS5_param_sweep.{ext}'
        fig.savefig(out_path, dpi=300, bbox_inches='tight')
        print(f"图已保存: {out_path}")
    plt.close()

    return df


if __name__ == '__main__':
    run_sweep()
