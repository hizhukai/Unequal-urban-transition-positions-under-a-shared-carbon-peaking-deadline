"""
论文2 模块4: XGBoost + SHAP 可解释驱动因素分析
================================================
识别各类城市碳排放变化的关键驱动因素, 揭示类间差异.

方法:
1. 全局模型: XGBoost 拟合 CO₂ 排放，SHAP 全局重要性
2. 分聚类模型: 每个聚类单独建模 → SHAP 对比
3. 交互效应: SHAP interaction values
4. 偏依赖图 (PDP): 关键变量阈值效应

输出:
    - shap_global.csv: 全局 SHAP 重要性
    - shap_by_cluster.csv: 分聚类 SHAP 对比
    - xgboost_metrics.csv: 模型性能
"""

import sys
import numpy as np
import pandas as pd
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

OUTPUT_DIR = PROJECT_ROOT / 'runtime_output'
OUTPUT_DIR.mkdir(exist_ok=True)

# 特征变量配置
FEATURE_COLS = [
    'gdp_per_capita',     # 人均 GDP (元)
    'pop_10k',            # 常住人口 (万人)
    'urbanization_rate',  # 城镇化率
    'industry2_share',    # 第二产业占比 (%)
    'industry3_share',    # 第三产业占比 (%)
    'energy_consumption', # 能源消费
]

FEATURE_LABELS = {
    'gdp_per_capita': '人均GDP',
    'pop_10k': '人口',
    'urbanization_rate': '城镇化率',
    'industry2_share': '第二产业占比',
    'industry3_share': '第三产业占比',
    'energy_consumption': '能源消费',
}

TARGET_COL = 'co2_mt'


def prepare_ml_data(panel: pd.DataFrame,
                    features: list = None) -> tuple:
    """
    从面板数据中提取 ML 可用的特征-目标矩阵.
    
    Returns:
        X, y, city_year_index
    """
    if features is None:
        features = FEATURE_COLS
    
    # 确保列存在
    available = [f for f in features if f in panel.columns]
    missing = [f for f in features if f not in panel.columns]
    if missing:
        print(f"[警告] 缺少特征: {missing}")
    
    # 只保留目标和特征都非空的行
    cols = available + [TARGET_COL, 'city', 'year']
    df = panel[cols].dropna(subset=available + [TARGET_COL])
    
    X = df[available].values
    y = df[TARGET_COL].values
    index = df[['city', 'year']].reset_index(drop=True)
    
    print(f"[ML数据] {len(df)} 样本, {len(available)} 特征, "
          f"{df['city'].nunique()} 城市")
    
    return X, y, index, available


def train_xgboost(X: np.ndarray, y: np.ndarray,
                  feature_names: list = None,
                  test_ratio: float = 0.2) -> dict:
    """
    训练 XGBoost 模型并计算 SHAP 值.
    
    Returns:
        dict: model, shap_values, X_test, y_test, metrics
    """
    import xgboost as xgb
    import shap
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
    
    # 划分训练/测试集
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_ratio, random_state=42
    )
    
    # XGBoost 参数
    params = {
        'n_estimators': 500,
        'max_depth': 6,
        'learning_rate': 0.05,
        'subsample': 0.8,
        'colsample_bytree': 0.8,
        'reg_alpha': 0.1,
        'reg_lambda': 1.0,
        'random_state': 42,
        'n_jobs': -1,
    }
    
    model = xgb.XGBRegressor(**params)
    model.fit(X_train, y_train,
              eval_set=[(X_test, y_test)],
              verbose=False)
    
    # 预测与评估
    y_pred = model.predict(X_test)
    metrics = {
        'r2': r2_score(y_test, y_pred),
        'mae': mean_absolute_error(y_test, y_pred),
        'rmse': np.sqrt(mean_squared_error(y_test, y_pred)),
        'n_train': len(X_train),
        'n_test': len(X_test),
    }
    
    print(f"  XGBoost: R²={metrics['r2']:.3f}, "
          f"MAE={metrics['mae']:.2f}, RMSE={metrics['rmse']:.2f}")
    
    # SHAP
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)
    
    return {
        'model': model,
        'explainer': explainer,
        'shap_values': shap_values,
        'X': X,
        'X_test': X_test,
        'y_test': y_test,
        'y_pred': y_pred,
        'metrics': metrics,
        'feature_names': feature_names,
    }


def compute_shap_importance(shap_values: np.ndarray,
                            feature_names: list) -> pd.DataFrame:
    """计算 SHAP 特征重要性 (mean |SHAP|)."""
    importance = pd.DataFrame({
        'feature': feature_names,
        'mean_abs_shap': np.abs(shap_values).mean(axis=0),
        'mean_shap': shap_values.mean(axis=0),
        'std_shap': shap_values.std(axis=0),
    })
    importance = importance.sort_values('mean_abs_shap', ascending=False)
    importance['rank'] = range(1, len(importance) + 1)
    return importance


def run_global_analysis(panel: pd.DataFrame) -> dict:
    """
    全局 XGBoost + SHAP 分析 (所有城市).
    """
    print("\n--- 全局 XGBoost + SHAP ---")
    X, y, index, feat_names = prepare_ml_data(panel)
    result = train_xgboost(X, y, feat_names)
    
    # SHAP 重要性
    importance = compute_shap_importance(result['shap_values'], feat_names)
    print(f"\n  全局 SHAP 排序:")
    for _, row in importance.iterrows():
        label = FEATURE_LABELS.get(row['feature'], row['feature'])
        print(f"    {row['rank']}. {label}: {row['mean_abs_shap']:.3f}")
    
    importance.to_csv(OUTPUT_DIR / 'shap_global.csv', 
                      index=False, encoding='utf-8-sig')
    
    result['importance'] = importance
    result['index'] = index
    return result


def run_cluster_analysis(panel: pd.DataFrame,
                         city_clusters: pd.DataFrame) -> pd.DataFrame:
    """
    分聚类 XGBoost + SHAP 分析.
    
    Args:
        panel: 面板数据
        city_clusters: columns = [city, cluster]
        
    Returns:
        DataFrame: 分聚类 SHAP 对比热力图数据
    """
    # 合并聚类标签
    panel_c = panel.merge(city_clusters, on='city', how='inner')
    
    all_importance = []
    all_metrics = []
    
    for cluster_id in sorted(panel_c['cluster'].unique()):
        subset = panel_c[panel_c['cluster'] == cluster_id]
        n_cities = subset['city'].nunique()
        print(f"\n--- 聚类 {cluster_id} ({n_cities} 城市) ---")
        
        X, y, index, feat_names = prepare_ml_data(subset)
        
        if len(X) < 50:
            print(f"  样本不足 ({len(X)} < 50), 跳过")
            continue
        
        result = train_xgboost(X, y, feat_names)
        importance = compute_shap_importance(result['shap_values'], feat_names)
        importance['cluster'] = cluster_id
        importance['n_cities'] = n_cities
        all_importance.append(importance)
        
        metrics = result['metrics']
        metrics['cluster'] = cluster_id
        metrics['n_cities'] = n_cities
        all_metrics.append(metrics)
    
    if all_importance:
        shap_comparison = pd.concat(all_importance, ignore_index=True)
        shap_comparison.to_csv(OUTPUT_DIR / 'shap_by_cluster.csv',
                               index=False, encoding='utf-8-sig')
        
        metrics_df = pd.DataFrame(all_metrics)
        metrics_df.to_csv(OUTPUT_DIR / 'xgboost_metrics.csv',
                          index=False, encoding='utf-8-sig')
        
        # 打印对比
        print(f"\n--- SHAP 分聚类对比 ---")
        pivot = shap_comparison.pivot_table(
            index='feature', columns='cluster', 
            values='rank', aggfunc='first'
        )
        print(pivot.to_string())
        
        return shap_comparison
    
    return pd.DataFrame()


if __name__ == '__main__':
    from shared.utils.emission_processor import load_panel
    
    # 加载面板数据
    panel = load_panel()
    
    # 全局分析
    global_result = run_global_analysis(panel)
    
    # 分聚类分析 (如果已有聚类结果)
    cluster_file = OUTPUT_DIR / 'city_clusters.csv'
    if cluster_file.exists():
        city_clusters = pd.read_csv(cluster_file)
        cluster_shap = run_cluster_analysis(panel, city_clusters)
    else:
        print("\n[提示] 未找到聚类结果, 请先运行 s2_dtw_clustering.py")
    
    print(f"\n结果已保存到 {OUTPUT_DIR}")
