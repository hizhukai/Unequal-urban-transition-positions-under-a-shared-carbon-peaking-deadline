"""
论文2 模块5: Monte Carlo 模拟转折时间
======================================
基于 STIRPAT 参数不确定性的 Monte Carlo 模拟, 汇总各路径的模拟转折时间分布.

方法:
1. STIRPAT 模型: ln(CO₂) = α + β₁ ln(Pop) + β₂ ln(GDP/pop) + β₃ ln(Urbanization)
2. 情景设计: BAU / 加速转型 / 低碳突破 (GDP增速, 产业结构, 城镇化率)
3. MC 模拟: 对 STIRPAT 系数添加正态扰动, 生成模拟轨迹
4. 分聚类模拟: 各聚类独立 STIRPAT → 各自模拟转折份额曲线
"""

import sys
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.linear_model import LinearRegression

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

OUTPUT_DIR = PROJECT_ROOT / 'runtime_output'
OUTPUT_DIR.mkdir(exist_ok=True)


def estimate_stirpat(panel: pd.DataFrame, cities: list = None) -> dict:
    """
    估计 STIRPAT 模型参数 (含能源消费).
    ln(CO₂) = α + β₁ ln(Pop) + β₂ ln(GDP_pc) + β₃ Urban + β₄ Industry2 + β₅ ln(Energy)
    
    Returns:
        dict: coefs, se, R2, model, has_energy
    """
    df = panel.copy()
    if cities is not None:
        df = df[df['city'].isin(cities)]
    
    # 检查是否有 energy_consumption
    has_energy = ('energy_consumption' in df.columns and 
                  df['energy_consumption'].notna().sum() > 20)
    
    required = ['co2_mt', 'pop_10k', 'gdp_per_capita', 
                'urbanization_rate', 'industry2_share']
    if has_energy:
        required.append('energy_consumption')
    
    df = df.dropna(subset=required)
    df = df[(df['co2_mt'] > 0) & (df['pop_10k'] > 0) & 
            (df['gdp_per_capita'] > 0)]
    if has_energy:
        df = df[df['energy_consumption'] > 0]
    
    y = np.log(df['co2_mt'].values)
    X_list = [
        np.log(df['pop_10k'].values),
        np.log(df['gdp_per_capita'].values),
        df['urbanization_rate'].values,
        df['industry2_share'].values,
    ]
    coef_names = ['intercept', 'ln_pop', 'ln_gdp_pc', 'urbanization', 'industry2']
    
    if has_energy:
        X_list.append(np.log(df['energy_consumption'].values))
        coef_names.append('ln_energy')
    
    X = np.column_stack(X_list)
    
    model = LinearRegression()
    model.fit(X, y)
    y_pred = model.predict(X)
    residuals = y - y_pred
    
    R2 = model.score(X, y)
    n, k = X.shape
    sigma2 = np.sum(residuals**2) / (n - k - 1)
    
    coefs = np.concatenate([[model.intercept_], model.coef_])
    
    # VIF 共线性诊断
    vif_values = {}
    var_names_for_vif = coef_names[1:]  # 不含 intercept
    for i in range(X.shape[1]):
        mask = [j for j in range(X.shape[1]) if j != i]
        X_other = X[:, mask]
        r2_i = LinearRegression().fit(X_other, X[:, i]).score(X_other, X[:, i])
        vif_values[var_names_for_vif[i]] = 1 / (1 - r2_i) if r2_i < 1 else float('inf')
    
    print(f"[STIRPAT] R² = {R2:.4f}, n = {n}, {'含能源' if has_energy else '无能源'}")
    for name, coef in zip(coef_names, coefs):
        vif_str = f"  (VIF={vif_values[name]:.1f})" if name in vif_values else ""
        print(f"  {name}: {coef:.4f}{vif_str}")
    
    # VIF > 10 的警告
    high_vif = {k: v for k, v in vif_values.items() if v > 5}
    if high_vif:
        print(f"  ⚠️ 共线性提示: {', '.join(f'{k}(VIF={v:.1f})' for k,v in high_vif.items())}")
        print(f"     能源变量与GDP/人口共线导致弹性分流, 各系数仍无偏但方差增大")
    
    return {
        'coefs': coefs,
        'coef_names': coef_names,
        'R2': R2,
        'sigma': np.sqrt(sigma2),
        'model': model,
        'n': n,
        'has_energy': has_energy,
        'vif': vif_values,
    }


def estimate_stirpat_panel_fe(panel: pd.DataFrame, cities: list = None) -> dict:
    """
    STIRPAT 面板固定效应稳健性检验.
    
    使用 within 变换 (城市级去均值) 消去个体固定效应:
        (y_it - ȳ_i) = β₁(x1_it - x̄1_i) + ... + ε_it
    
    与 pooled OLS 对比:
    - FE 捕获 *within-city* 时序变化的弹性 (排除城市间异质性)
    - Pooled 混合 between + within, 系数可能受遗漏变量偏误
    - 若 FE 与 Pooled 系数方向一致且量级接近, 说明 Pooled 结果稳健
    
    Returns:
        dict: fe_coefs, pooled_coefs, comparison_table, hausman_stat
    """
    from scipy.stats import chi2
    
    df = panel.copy()
    if cities is not None:
        df = df[df['city'].isin(cities)]
    
    has_energy = ('energy_consumption' in df.columns and 
                  df['energy_consumption'].notna().sum() > 20)
    
    required = ['city', 'year', 'co2_mt', 'pop_10k', 'gdp_per_capita',
                'urbanization_rate', 'industry2_share']
    if has_energy:
        required.append('energy_consumption')
    
    df = df.dropna(subset=required)
    df = df[(df['co2_mt'] > 0) & (df['pop_10k'] > 0) &
            (df['gdp_per_capita'] > 0)]
    if has_energy:
        df = df[df['energy_consumption'] > 0]
    
    # 构建变量矩阵
    df['ln_co2'] = np.log(df['co2_mt'])
    df['ln_pop'] = np.log(df['pop_10k'])
    df['ln_gdp_pc'] = np.log(df['gdp_per_capita'])
    if has_energy:
        df['ln_energy'] = np.log(df['energy_consumption'])
    
    dep_var = 'ln_co2'
    indep_vars = ['ln_pop', 'ln_gdp_pc', 'urbanization_rate', 'industry2_share']
    if has_energy:
        indep_vars.append('ln_energy')
    
    coef_names_fe = indep_vars.copy()
    
    # 仅保留有≥3年观测的城市 (FE需要足够时序变异)
    city_counts = df.groupby('city').size()
    valid_cities = city_counts[city_counts >= 3].index
    df = df[df['city'].isin(valid_cities)]
    N_cities = df['city'].nunique()
    
    print(f"\n{'='*60}")
    print(f"STIRPAT 面板固定效应稳健性检验")
    print(f"{'='*60}")
    print(f"[面板] {N_cities} 城市, {df['year'].nunique()} 年, {len(df)} 观测")
    
    # ---- Pooled OLS ----
    y_pooled = df[dep_var].values
    X_pooled = df[indep_vars].values
    
    model_pooled = LinearRegression()
    model_pooled.fit(X_pooled, y_pooled)
    coefs_pooled = model_pooled.coef_
    R2_pooled = model_pooled.score(X_pooled, y_pooled)
    resid_pooled = y_pooled - model_pooled.predict(X_pooled)
    
    # ---- Within (FE) 变换 ----
    # 对每个变量去城市均值
    all_vars = [dep_var] + indep_vars
    df_demeaned = df.copy()
    city_means = df.groupby('city')[all_vars].transform('mean')
    for v in all_vars:
        df_demeaned[v] = df[v] - city_means[v]
    
    y_fe = df_demeaned[dep_var].values
    X_fe = df_demeaned[indep_vars].values
    
    # FE OLS (无截距, 因为去均值后截距=0)
    model_fe = LinearRegression(fit_intercept=False)
    model_fe.fit(X_fe, y_fe)
    coefs_fe = model_fe.coef_
    y_pred_fe = model_fe.predict(X_fe)
    resid_fe = y_fe - y_pred_fe
    
    # FE R² (within R²)
    SSR_fe = np.sum(resid_fe**2)
    SST_fe = np.sum(y_fe**2)  # 去均值后 ȳ=0
    R2_within = 1 - SSR_fe / SST_fe
    
    # FE 标准误
    n_obs = len(y_fe)
    k = len(indep_vars)
    dof = n_obs - N_cities - k  # 扣除 N 个城市FE + K个系数
    sigma2_fe = SSR_fe / dof if dof > 0 else SSR_fe / (n_obs - k)
    
    try:
        XtX_inv = np.linalg.inv(X_fe.T @ X_fe)
        se_fe = np.sqrt(np.diag(sigma2_fe * XtX_inv))
    except:
        se_fe = np.full(k, np.nan)
    
    from scipy.stats import t as t_dist
    t_stats = coefs_fe / se_fe
    p_values = 2 * (1 - t_dist.cdf(np.abs(t_stats), dof))
    
    # Pooled OLS 标准误
    sigma2_pooled = np.sum(resid_pooled**2) / (n_obs - k - 1)
    try:
        XtX_inv_p = np.linalg.inv(X_pooled.T @ X_pooled)
        se_pooled = np.sqrt(np.diag(sigma2_pooled * XtX_inv_p))
    except:
        se_pooled = np.full(k, np.nan)
    
    # ---- Hausman 检验 ----
    # H0: Pooled OLS 一致 (无需 FE)
    # H1: FE 优于 Pooled (存在遗漏的城市异质性)
    diff_coefs = coefs_fe - coefs_pooled
    try:
        diff_var = sigma2_fe * XtX_inv - sigma2_pooled * XtX_inv_p
        hausman_stat = diff_coefs @ np.linalg.inv(diff_var) @ diff_coefs
        hausman_p = 1 - chi2.cdf(hausman_stat, k)
    except:
        hausman_stat = np.nan
        hausman_p = np.nan
    
    # ---- 系数对比表 ----
    comparison = []
    for i, name in enumerate(coef_names_fe):
        comparison.append({
            'variable': name,
            'pooled_coef': coefs_pooled[i],
            'pooled_se': se_pooled[i],
            'fe_coef': coefs_fe[i],
            'fe_se': se_fe[i],
            'fe_p': p_values[i],
            'fe_sig': '***' if p_values[i] < 0.01 else '**' if p_values[i] < 0.05 else '*' if p_values[i] < 0.1 else '',
            'diff_%': abs(coefs_fe[i] - coefs_pooled[i]) / (abs(coefs_pooled[i]) + 1e-10) * 100,
            'same_sign': '✅' if (coefs_fe[i] * coefs_pooled[i]) > 0 else '❌',
        })
    
    comp_df = pd.DataFrame(comparison)
    
    # ---- 输出 ----
    print(f"\n[Pooled OLS]  R² = {R2_pooled:.4f}")
    print(f"[Panel FE]    R²_within = {R2_within:.4f}")
    print(f"[Hausman]     χ² = {hausman_stat:.2f}, p = {hausman_p:.4f}" + 
          (" → FE优于Pooled" if hausman_p < 0.05 else " → Pooled可接受"))
    
    print(f"\n{'变量':<20s} {'Pooled':>9s} {'FE':>9s} {'差异%':>7s} {'同号':>4s} {'FE显著':>6s}")
    print("-" * 60)
    for _, row in comp_df.iterrows():
        print(f"{row['variable']:<20s} {row['pooled_coef']:>9.4f} {row['fe_coef']:>9.4f} "
              f"{row['diff_%']:>6.1f}% {row['same_sign']:>4s} {row['fe_sig']:>6s}")
    
    # 稳健性判断
    same_sign_pct = comp_df['same_sign'].apply(lambda x: 1 if x == '✅' else 0).mean()
    avg_diff = comp_df['diff_%'].mean()
    
    print(f"\n[稳健性评估]")
    print(f"  系数同号率: {same_sign_pct:.0%}")
    print(f"  平均系数差异: {avg_diff:.1f}%")
    
    if same_sign_pct >= 0.8 and avg_diff < 100:
        print(f"  ✅ Pooled OLS 与 Panel FE 系数方向一致, Pooled 结果稳健")
    elif same_sign_pct >= 0.6:
        print(f"  ⚠️ 部分系数方向不一致, Pooled 结果需谨慎解读")
    else:
        print(f"  ❌ 多数系数方向不一致, Pooled 结果不稳健")
    
    # 保存
    comp_df.to_csv(OUTPUT_DIR / 'stirpat_fe_robustness.csv', 
                   index=False, encoding='utf-8-sig')
    print(f"\n  结果保存到 stirpat_fe_robustness.csv")
    
    return {
        'fe_coefs': coefs_fe,
        'pooled_coefs': coefs_pooled,
        'coef_names': coef_names_fe,
        'R2_pooled': R2_pooled,
        'R2_within': R2_within,
        'hausman_stat': hausman_stat,
        'hausman_p': hausman_p,
        'comparison': comp_df,
        'n_cities': N_cities,
        'n_obs': n_obs,
    }


def design_scenarios(cluster_profile: dict = None) -> dict:
    """
    设计三种情景的参数增长路径 (2020-2035).
    含能源效率变化参数 (energy_change: 年变化率, 负=节能).
    
    BAU-LOW_CARBON 间参数差距加大, 以产生更明显的达峰时间差异.
    """
    base = {
        'HIGH_CARBON': {
            'name': '高碳粗放',
            'pop_growth': 0.005,           # 人口快增长
            'gdp_pc_growth': 0.08,         # 8% (粗放高增长)
            'urban_change': 0.006,
            'industry2_change': 0.002,     # 工业化继续
            'energy_change': 0.05,         # 能源消费年增5%
        },
        'BAU': {
            'name': '惯性发展',
            'pop_growth': 0.003,
            'gdp_pc_growth': 0.06,         # 6% (惯性增长)
            'urban_change': 0.008,
            'industry2_change': -0.002,    # 缓慢去工业化
            'energy_change': 0.03,         # 能源消费年增3%
        },
        'LOW_CARBON': {
            'name': '低碳转型',
            'pop_growth': -0.001,          # 人口负增长
            'gdp_pc_growth': 0.03,         # 3% (质量型增长)
            'urban_change': 0.012,
            'industry2_change': -0.015,    # 快速去工业化
            'energy_change': -0.02,        # 能源消费年降2%
        }
    }
    
    if cluster_profile is None:
        return base
    
    trend = cluster_profile.get('trend', 'stable')
    avg_ind2 = cluster_profile.get('avg_industry2', 0.4)
    avg_urban = cluster_profile.get('avg_urban', 0.6)
    avg_gdp_pc = cluster_profile.get('avg_gdp_pc', 60000)
    
    scenarios = {}
    for key, s in base.items():
        s = s.copy()
        
        if trend == 'declining':
            # 衰退型: GDP低增长, 人口外流, 能源快速下降
            s['pop_growth'] -= 0.003
            s['gdp_pc_growth'] -= 0.015
            s['industry2_change'] -= 0.005
            s['energy_change'] -= 0.02
        elif trend == 'rising':
            # 高速增长型: GDP高增长, 能源需求旺盛
            s['pop_growth'] += 0.002
            s['gdp_pc_growth'] += 0.015
            s['industry2_change'] += 0.005
            s['energy_change'] += 0.02
        
        # 高二产: 去工业化空间更大
        if avg_ind2 > 0.45:
            s['industry2_change'] -= 0.003
            s['energy_change'] -= 0.01
        
        # 低城镇化: 城镇化加速
        if avg_urban < 0.5:
            s['urban_change'] += 0.005
        elif avg_urban > 0.7:
            s['urban_change'] -= 0.003
        
        # 高GDP: 增速放缓 + 节能空间大
        if avg_gdp_pc > 80000:
            s['gdp_pc_growth'] -= 0.01
            s['energy_change'] -= 0.01
        
        scenarios[key] = s
    
    return scenarios


def simulate_trajectories(stirpat: dict, base_values: dict,
                           scenario: dict,
                           n_simulations: int = 100000,
                           simulation_years: tuple = (2020, 2035)) -> pd.DataFrame:
    """
    Monte Carlo 模拟达峰时间.
    
    Args:
        stirpat: STIRPAT 估计结果
        base_values: 各变量 2019 基期值 {pop, gdp_pc, urban, industry2}
        scenario: 情景参数
        n_simulations: 模拟次数
        
    Returns:
        DataFrame: columns = [sim_id, year, co2_simulated]
    """
    coefs = stirpat['coefs']
    sigma = stirpat['sigma']
    has_energy = stirpat.get('has_energy', False)
    
    years = list(range(simulation_years[0], simulation_years[1] + 1))
    n_years = len(years)
    
    results = []
    peak_years = []
    
    for sim in range(n_simulations):
        # 对系数添加正态扰动 (±10% 标准差)
        coefs_perturbed = coefs + np.random.normal(0, abs(coefs) * 0.1)
        
        sim_emissions = []
        
        pop = base_values['pop']
        gdp_pc = base_values['gdp_pc']
        urban = base_values['urban']
        ind2 = base_values['industry2']
        energy = base_values.get('energy', 100)
        
        for t, year in enumerate(years):
            pop *= (1 + scenario['pop_growth'])
            gdp_pc *= (1 + scenario['gdp_pc_growth'])
            urban = min(1.0, urban + scenario['urban_change'])
            ind2 = max(0.05, ind2 + scenario['industry2_change'])
            energy_growth = scenario.get('energy_change', 0.01)
            energy *= (1 + energy_growth)
            energy = max(1.0, energy)
            
            # STIRPAT trajectory simulation (5 or 6 variables)
            ln_co2 = (coefs_perturbed[0] + 
                      coefs_perturbed[1] * np.log(pop) +
                      coefs_perturbed[2] * np.log(gdp_pc) +
                      coefs_perturbed[3] * urban +
                      coefs_perturbed[4] * ind2)
            
            if has_energy and len(coefs_perturbed) > 5:
                ln_co2 += coefs_perturbed[5] * np.log(energy)
            
            ln_co2 += np.random.normal(0, sigma * 0.5)
            
            co2 = np.exp(ln_co2)
            sim_emissions.append(co2)
            
            results.append({
                'sim_id': sim,
                'year': year,
                'co2_simulated': co2,
            })
        
        # 找达峰年
        peak_idx = np.argmax(sim_emissions)
        if peak_idx < len(sim_emissions) - 1:
            peak_years.append(years[peak_idx])
        else:
            peak_years.append(None)  # 未达峰
    
    df = pd.DataFrame(results)
    
    # Summarize simulated turning years
    peak_years_valid = [y for y in peak_years if y is not None]
    if peak_years_valid:
        turning_share = len(peak_years_valid) / n_simulations
        peak_median = int(np.median(peak_years_valid))
        peak_5 = int(np.percentile(peak_years_valid, 5))
        peak_95 = int(np.percentile(peak_years_valid, 95))
        print(f"  Simulated turning share: {turning_share:.1%}; "
              f"median simulated turning year: {peak_median}; "
              f"5th to 95th percentile: [{peak_5}, {peak_95}]")
    else:
        print(f"  No simulated turning point by {simulation_years[1]}")
    
    return df


def run_prediction_by_cluster(panel: pd.DataFrame,
                               city_clusters: pd.DataFrame,
                               n_simulations: int = 100000) -> dict:
    """
    分聚类执行 Monte Carlo 模拟.
    为每个聚类计算特征画像, 差异化情景参数.
    """
    all_results = {}
    
    panel_c = panel.merge(city_clusters, on='city', how='inner')
    
    for cluster_id in sorted(panel_c['cluster'].unique()):
        cluster_cities = city_clusters[city_clusters['cluster'] == cluster_id]['city'].tolist()
        subset = panel_c[panel_c['cluster'] == cluster_id]
        
        print(f"\n{'='*50}")
        print(f"聚类 {cluster_id} ({len(cluster_cities)} 城市)")
        print(f"{'='*50}")
        
        # 计算聚类特征画像
        early = subset[subset['year'] <= 2010]
        late = subset[subset['year'] >= 2015]
        
        early_co2 = early.groupby('city')['co2_mt'].mean().mean() if len(early) > 0 else 1
        late_co2 = late.groupby('city')['co2_mt'].mean().mean() if len(late) > 0 else 1
        co2_change = (late_co2 - early_co2) / max(early_co2, 0.001)
        
        if co2_change < -0.05:
            trend = 'declining'
        elif co2_change > 0.2:
            trend = 'rising'
        else:
            trend = 'stable'
        
        latest = subset[subset['year'] == subset['year'].max()]
        avg_ind2 = latest['industry2_share'].mean() if 'industry2_share' in latest else 0.4
        avg_urban = latest['urbanization_rate'].mean() if 'urbanization_rate' in latest else 0.6
        avg_gdp_pc = latest['gdp_per_capita'].mean() if 'gdp_per_capita' in latest else 60000
        
        # NaN 安全
        avg_ind2 = avg_ind2 if not np.isnan(avg_ind2) else 0.4
        avg_urban = avg_urban if not np.isnan(avg_urban) else 0.6
        avg_gdp_pc = avg_gdp_pc if not np.isnan(avg_gdp_pc) else 60000
        
        cluster_profile = {
            'trend': trend,
            'avg_industry2': avg_ind2,
            'avg_urban': avg_urban,
            'avg_gdp_pc': avg_gdp_pc,
        }
        print(f"  特征画像: trend={trend}, CO₂变化={co2_change:+.1%}, "
              f"二产={avg_ind2:.1f}%, 城镇化={avg_urban:.1%}, GDP_pc={avg_gdp_pc:.0f}")
        
        # 差异化情景
        scenarios = design_scenarios(cluster_profile)
        
        # STIRPAT 估计
        stirpat = estimate_stirpat(subset)
        
        if stirpat['n'] < 20:
            print(f"  样本不足, 跳过")
            continue
        
        # 基期值 (2019 年聚类平均)
        base_year = subset[subset['year'] == subset['year'].max()]
        base_values = {
            'pop': base_year['pop_10k'].mean() if 'pop_10k' in base_year else 50,
            'gdp_pc': base_year['gdp_per_capita'].mean() if 'gdp_per_capita' in base_year else 60000,
            'urban': base_year['urbanization_rate'].mean() if 'urbanization_rate' in base_year else 0.6,
            'industry2': base_year['industry2_share'].mean() if 'industry2_share' in base_year else 0.4,
            'energy': base_year['energy_consumption'].mean() if 'energy_consumption' in base_year else 100,
        }
        
        # 用默认值替换 NaN
        defaults = {'pop': 50, 'gdp_pc': 60000, 'urban': 0.6, 'industry2': 0.4, 'energy': 100}
        for k, v in base_values.items():
            if np.isnan(v):
                base_values[k] = defaults[k]
        
        cluster_results = {}
        for scenario_key, scenario in scenarios.items():
            print(f"\n--- 情景: {scenario['name']} ---")
            print(f"    参数: pop_g={scenario['pop_growth']:.3f}, "
                  f"gdp_g={scenario['gdp_pc_growth']:.3f}, "
                  f"urban_Δ={scenario['urban_change']:.3f}, "
                  f"ind2_Δ={scenario['industry2_change']:.3f}, "
                  f"energy_Δ={scenario.get('energy_change', 0):.3f}")
            mc = simulate_trajectories(stirpat, base_values, scenario,
                                       n_simulations=n_simulations)
            mc['cluster'] = cluster_id
            mc['scenario'] = scenario_key
            cluster_results[scenario_key] = mc
        
        all_results[cluster_id] = cluster_results
    
    # 合并保存
    all_dfs = []
    for cluster_id, cluster_res in all_results.items():
        for scenario_key, mc_df in cluster_res.items():
            all_dfs.append(mc_df)
    
    if all_dfs:
        combined = pd.concat(all_dfs, ignore_index=True)
        combined.to_csv(OUTPUT_DIR / 'mc_predictions.csv', index=False)
        print(f"\nSimulated trajectories saved to {OUTPUT_DIR / 'mc_predictions.csv'}")
        
        # ===== 政策约束分析: 2030 模拟转折份额与政策缺口 =====
        print(f"\n{'='*60}")
        print("Scenario comparison: simulated turning shares by 2030")
        print(f"{'='*60}")
        
        policy_rows = []
        for cluster_id in sorted(combined['cluster'].unique()):
            for scenario in ['HIGH_CARBON', 'BAU', 'LOW_CARBON']:
                sub = combined[(combined['cluster']==cluster_id) & 
                              (combined['scenario']==scenario)]
                if len(sub) == 0:
                    continue
                
                peak_years = []
                for sid in sub['sim_id'].unique():
                    sim = sub[sub['sim_id']==sid].sort_values('year')
                    em = sim['co2_simulated'].values
                    pi = np.argmax(em)
                    if pi < len(em) - 2:
                        peak_years.append(sim['year'].values[pi])
                
                n_sims = len(sub['sim_id'].unique())
                n_peaked = len(peak_years)
                simulated_turning_share_any = n_peaked / n_sims
                
                if peak_years:
                    median_peak = np.median(peak_years)
                    simulated_turning_share_by_2030 = sum(1 for y in peak_years if y <= 2030) / n_sims
                    gap = max(0, median_peak - 2030)
                else:
                    median_peak = np.nan
                    simulated_turning_share_by_2030 = 0
                    gap = np.nan
                
                policy_rows.append({
                    'cluster': cluster_id,
                    'scenario': scenario,
                    'median_simulated_turning_year': median_peak,
                    'simulated_turning_share_any': simulated_turning_share_any,
                    'simulated_turning_share_by_2030': simulated_turning_share_by_2030,
                    'policy_gap_years': gap,
                })
                
                status = "high" if simulated_turning_share_by_2030 > 0.5 else "intermediate" if simulated_turning_share_by_2030 > 0.2 else "low"
                print(f"  C{cluster_id} {scenario:>12}: "
                      f"median={median_peak:.0f}, "
                      f"simulated share by 2030={simulated_turning_share_by_2030:.0%} ({status})")
        
        policy_df = pd.DataFrame(policy_rows)
        policy_df.to_csv(OUTPUT_DIR / 'policy_gap_analysis.csv', 
                        index=False, encoding='utf-8-sig')
        
        # Summary
        hc_rows = policy_df[policy_df['scenario']=='HIGH_CARBON']
        bau_rows = policy_df[policy_df['scenario']=='BAU']
        lc_rows = policy_df[policy_df['scenario']=='LOW_CARBON']
        if len(hc_rows) > 0 and len(bau_rows) > 0 and len(lc_rows) > 0:
            avg_hc_share = hc_rows['simulated_turning_share_by_2030'].mean()
            avg_bau_share = bau_rows['simulated_turning_share_by_2030'].mean()
            avg_lc_share = lc_rows['simulated_turning_share_by_2030'].mean()
            print(f"\n  [Summary] HIGH_CARBON simulated share by 2030: {avg_hc_share:.0%}")
            print(f"         BAU simulated share by 2030: {avg_bau_share:.0%}")
            print(f"         LOW_CARBON simulated share by 2030: {avg_lc_share:.0%}")
            print(f"         High-to-low simulated-share contrast: {avg_lc_share-avg_hc_share:+.0%}")
    
    return all_results


def run_prediction_by_city(panel: pd.DataFrame,
                           city_clusters: pd.DataFrame,
                           n_simulations: int = 100000) -> pd.DataFrame:
    """
    城市级 Monte Carlo 模拟.
    
    对每个城市使用:
    - 所在cluster的 STIRPAT 系数 (cluster-level pooled estimation)
    - 城市自身的 2019 年基期值 (city-specific base values)
    - 所在cluster的差异化情景参数
    
    输出每个城市在各情景下的模拟转折年份分布.
    
    Args:
        panel: 全面板数据
        city_clusters: 城市-聚类对应表
        n_simulations: 每个城市每个情景的模拟次数 (默认100000)
    
    Returns:
        DataFrame: 城市级达峰摘要
    """
    panel_c = panel.merge(city_clusters, on='city', how='inner')
    
    # ---- Step 1: 为每个cluster训练 STIRPAT 并获取情景参数 ----
    cluster_models = {}
    cluster_scenarios = {}
    
    for cluster_id in sorted(panel_c['cluster'].unique()):
        subset = panel_c[panel_c['cluster'] == cluster_id]
        cluster_cities = city_clusters[city_clusters['cluster'] == cluster_id]['city'].tolist()
        
        print(f"\n{'='*50}")
        print(f"[城市级MC] 聚类 {cluster_id} ({len(cluster_cities)} 城市)")
        print(f"{'='*50}")
        
        # STIRPAT 估计
        stirpat = estimate_stirpat(subset)
        if stirpat['n'] < 20:
            print(f"  样本不足, 跳过")
            continue
        cluster_models[cluster_id] = stirpat
        
        # 聚类特征画像
        early = subset[subset['year'] <= 2010]
        late = subset[subset['year'] >= 2015]
        early_co2 = early.groupby('city')['co2_mt'].mean().mean() if len(early) > 0 else 1
        late_co2 = late.groupby('city')['co2_mt'].mean().mean() if len(late) > 0 else 1
        co2_change = (late_co2 - early_co2) / max(early_co2, 0.001)
        
        if co2_change < -0.05:
            trend = 'declining'
        elif co2_change > 0.2:
            trend = 'rising'
        else:
            trend = 'stable'
        
        latest = subset[subset['year'] == subset['year'].max()]
        avg_ind2 = latest['industry2_share'].mean() if 'industry2_share' in latest else 0.4
        avg_urban = latest['urbanization_rate'].mean() if 'urbanization_rate' in latest else 0.6
        avg_gdp_pc = latest['gdp_per_capita'].mean() if 'gdp_per_capita' in latest else 60000
        
        for v_name, v_val, v_def in [('avg_ind2', avg_ind2, 0.4), 
                                      ('avg_urban', avg_urban, 0.6),
                                      ('avg_gdp_pc', avg_gdp_pc, 60000)]:
            if np.isnan(v_val):
                locals()[v_name] = v_def
        
        cluster_profile = {
            'trend': trend, 'avg_industry2': avg_ind2,
            'avg_urban': avg_urban, 'avg_gdp_pc': avg_gdp_pc,
        }
        cluster_scenarios[cluster_id] = design_scenarios(cluster_profile)
    
    # ---- Step 2: 对每个城市执行MC模拟 ----
    all_trajectories = []  # 完整轨迹 (可选保存)
    summary_rows = []      # 达峰摘要
    
    latest_year = panel_c['year'].max()
    
    for _, row in city_clusters.iterrows():
        city = row['city']
        cluster_id = row['cluster']
        
        if cluster_id not in cluster_models:
            continue
        
        stirpat = cluster_models[cluster_id]
        scenarios = cluster_scenarios[cluster_id]
        coefs = stirpat['coefs']
        sigma = stirpat['sigma']
        has_energy = stirpat.get('has_energy', False)
        
        # 获取城市自身的基期值
        city_latest = panel_c[(panel_c['city'] == city) & 
                              (panel_c['year'] == latest_year)]
        if len(city_latest) == 0:
            # 尝试最近可用年份
            city_data = panel_c[panel_c['city'] == city].sort_values('year')
            if len(city_data) == 0:
                continue
            city_latest = city_data.iloc[[-1]]
        
        city_row = city_latest.iloc[0]
        base_values = {
            'pop': city_row.get('pop_10k', 50),
            'gdp_pc': city_row.get('gdp_per_capita', 60000),
            'urban': city_row.get('urbanization_rate', 0.6),
            'industry2': city_row.get('industry2_share', 0.4),
            'energy': city_row.get('energy_consumption', 100),
        }
        
        # NaN 安全
        defaults = {'pop': 50, 'gdp_pc': 60000, 'urban': 0.6, 
                    'industry2': 0.4, 'energy': 100}
        for k, v in base_values.items():
            if pd.isna(v) or v <= 0:
                base_values[k] = defaults[k]
        
        for scenario_key, scenario in scenarios.items():
            peak_years = []
            
            for sim in range(n_simulations):
                coefs_perturbed = coefs + np.random.normal(0, abs(coefs) * 0.1)
                
                pop = base_values['pop']
                gdp_pc = base_values['gdp_pc']
                urban = base_values['urban']
                ind2 = base_values['industry2']
                energy = base_values['energy']
                
                sim_emissions = []
                years = list(range(2020, 2036))
                
                for year in years:
                    pop *= (1 + scenario['pop_growth'])
                    gdp_pc *= (1 + scenario['gdp_pc_growth'])
                    urban = min(1.0, urban + scenario['urban_change'])
                    ind2 = max(0.05, ind2 + scenario['industry2_change'])
                    energy_growth = scenario.get('energy_change', 0.01)
                    energy *= (1 + energy_growth)
                    energy = max(1.0, energy)
                    
                    ln_co2 = (coefs_perturbed[0] +
                              coefs_perturbed[1] * np.log(pop) +
                              coefs_perturbed[2] * np.log(gdp_pc) +
                              coefs_perturbed[3] * urban +
                              coefs_perturbed[4] * ind2)
                    
                    if has_energy and len(coefs_perturbed) > 5:
                        ln_co2 += coefs_perturbed[5] * np.log(energy)
                    
                    ln_co2 += np.random.normal(0, sigma * 0.5)
                    co2 = np.exp(ln_co2)
                    sim_emissions.append(co2)
                
                # 找达峰年
                peak_idx = np.argmax(sim_emissions)
                if peak_idx < len(sim_emissions) - 2:
                    peak_years.append(years[peak_idx])
            
            # 汇总该城市×该情景的达峰统计
            n_peaked = len(peak_years)
            simulated_turning_share_any = n_peaked / n_simulations
            simulated_turning_share_by_2030 = sum(1 for y in peak_years if y <= 2030) / n_simulations if peak_years else 0
            median_peak = np.median(peak_years) if peak_years else np.nan
            
            summary_rows.append({
                'city': city,
                'cluster': cluster_id,
                'scenario': scenario_key,
                'simulated_turning_share_any': simulated_turning_share_any,
                'simulated_turning_share_by_2030': simulated_turning_share_by_2030,
                'median_simulated_turning_year': median_peak,
                'n_simulations': n_simulations,
            })
    
    # ---- Step 3: 保存结果 ----
    summary_df = pd.DataFrame(summary_rows)
    summary_df.to_csv(OUTPUT_DIR / 'mc_city_peak_summary.csv',
                      index=False, encoding='utf-8-sig')
    
    print(f"\n{'='*60}")
    print(f"城市级MC预测完成: {len(summary_df)} 条记录")
    print(f"  {summary_df['city'].nunique()} 城市 × {summary_df['scenario'].nunique()} 情景")
    print(f"  结果保存到 mc_city_peak_summary.csv")
    print(f"{'='*60}")
    
    # 汇总统计
    for scenario in ['LOW_CARBON', 'BAU', 'HIGH_CARBON']:
        s_df = summary_df[summary_df['scenario'] == scenario]
        avg_share = s_df['simulated_turning_share_by_2030'].mean()
        n_high_share = (s_df['simulated_turning_share_by_2030'] > 0.5).sum()
        print(f"  {scenario:>12}: mean simulated share by 2030={avg_share:.1%}, "
              f"cities above 50% share={n_high_share}/{len(s_df)}")
    
    return summary_df


def backtest_stirpat(panel: pd.DataFrame, 
                     train_end: int = 2015,
                     test_start: int = 2016,
                     test_end: int = 2019) -> pd.DataFrame:
    """
    STIRPAT-MC 模型回测（全样本口径）.
    
    用 2001-train_end 数据训练 STIRPAT, 以 train_end 年为基期,
    以 train_end→test_end 的实际增长率为情景, 逐年估计并与实际排放对比.
    本函数返回所有满足基期和测试期完整性要求的城市。
    若要生成与分聚类情景比较直接对应的回测摘要,
    需在结果文件基础上再与 city_clusters.csv 合并后筛选。
    
    Returns:
        DataFrame: 城市级回测结果 (actual, fitted, APE)
    """
    print("\n" + "=" * 60)
    print(f"STIRPAT 回测: {train_end+1}-{test_end} fitted and observed values")
    print("=" * 60)
    
    # 1. 仅用训练期数据估计 STIRPAT
    train_panel = panel[panel['year'] <= train_end].copy()
    print(f"\n[训练] 2001-{train_end} 数据")
    stirpat_train = estimate_stirpat(train_panel)
    
    # 2. 获取基期和测试期数据
    test_years = list(range(test_start, test_end + 1))
    
    required = ['co2_mt', 'pop_10k', 'gdp_per_capita', 
                'urbanization_rate', 'industry2_share']
    has_energy = stirpat_train['has_energy']
    if has_energy:
        required.append('energy_consumption')
    
    # 找到在基期和测试期都有完整数据的城市
    base_year_data = panel[panel['year'] == train_end].dropna(subset=required)
    base_cities = set(base_year_data['city'].unique())
    
    test_data = panel[(panel['year'] >= test_start) & (panel['year'] <= test_end)]
    
    results = []
    city_mapes = []
    
    for city in sorted(base_cities):
        city_base = base_year_data[base_year_data['city'] == city].iloc[0]
        city_test = test_data[test_data['city'] == city].sort_values('year')
        
        if len(city_test) < len(test_years):
            continue
        
        # 检查测试期数据完整性
        city_test = city_test.dropna(subset=['co2_mt'])
        if len(city_test) < len(test_years):
            continue
        
        # 基期值
        pop = city_base['pop_10k']
        gdp_pc = city_base['gdp_per_capita']
        urban = city_base['urbanization_rate']
        ind2 = city_base['industry2_share']
        energy = city_base.get('energy_consumption', 100)
        
        if any(v <= 0 or pd.isna(v) for v in [pop, gdp_pc]):
            continue
        
        coefs = stirpat_train['coefs']
        
        city_apes = []
        for _, test_row in city_test.iterrows():
            year = int(test_row['year'])
            actual = test_row['co2_mt']
            
            # 使用当年实际驱动变量值 (不是预测)
            pop_yr = test_row['pop_10k'] if not pd.isna(test_row['pop_10k']) else pop
            gdp_yr = test_row['gdp_per_capita'] if not pd.isna(test_row['gdp_per_capita']) else gdp_pc
            urban_yr = test_row['urbanization_rate'] if not pd.isna(test_row['urbanization_rate']) else urban
            ind2_yr = test_row['industry2_share'] if not pd.isna(test_row['industry2_share']) else ind2
            
            if pop_yr <= 0 or gdp_yr <= 0:
                continue
            
            # STIRPAT 预测
            ln_co2 = (coefs[0] + 
                      coefs[1] * np.log(pop_yr) +
                      coefs[2] * np.log(gdp_yr) +
                      coefs[3] * urban_yr +
                      coefs[4] * ind2_yr)
            
            if has_energy and len(coefs) > 5:
                energy_yr = test_row.get('energy_consumption', energy)
                if not pd.isna(energy_yr) and energy_yr > 0:
                    ln_co2 += coefs[5] * np.log(energy_yr)
            
            predicted = np.exp(ln_co2)
            ape = abs(predicted - actual) / actual * 100
            
            results.append({
                'city': city,
                'year': year,
                'actual': actual,
                'predicted': predicted,
                'error': predicted - actual,
                'APE': ape,
            })
            city_apes.append(ape)
        
        if city_apes:
            city_mapes.append(np.mean(city_apes))
    
    df = pd.DataFrame(results)
    
    if len(df) == 0:
        print("[回测] 无有效城市!")
        return df
    
    # 汇总统计
    mape = df['APE'].mean()
    mae = df['error'].abs().mean()
    from scipy.stats import pearsonr
    r_val, _ = pearsonr(df['actual'], df['predicted'])
    r2_bt = r_val ** 2
    
    print(f"\n[回测结果] {len(df)} 条预测, {len(set(df['city']))} 城市")
    print(f"  MAPE = {mape:.1f}%")
    print(f"  MAE  = {mae:.2f} Mt CO₂")
    print(f"  R²   = {r2_bt:.4f}")
    
    # 分年份
    print(f"\n  逐年MAPE:")
    for year in test_years:
        yr_df = df[df['year'] == year]
        if len(yr_df) > 0:
            print(f"    {year}: MAPE={yr_df['APE'].mean():.1f}%, "
                  f"n={len(yr_df)} 城市")
    
    # MAPE分布
    mape_p25 = np.percentile(city_mapes, 25) if city_mapes else 0
    mape_p50 = np.percentile(city_mapes, 50) if city_mapes else 0
    mape_p75 = np.percentile(city_mapes, 75) if city_mapes else 0
    print(f"\n  城市MAPE分布: P25={mape_p25:.1f}%, P50={mape_p50:.1f}%, P75={mape_p75:.1f}%")
    
    # 保存
    df.to_csv(OUTPUT_DIR / 'stirpat_backtest.csv', 
              index=False, encoding='utf-8-sig')
    print(f"\n  回测结果已保存到 stirpat_backtest.csv")
    
    return df


if __name__ == '__main__':
    from shared.utils.emission_processor import load_panel
    
    panel = load_panel()
    
    # 全局 STIRPAT
    print("--- 全局 STIRPAT 估计 ---")
    stirpat = estimate_stirpat(panel)
    
    # 分聚类预测 (如果聚类结果存在)
    cluster_file = OUTPUT_DIR / 'city_clusters.csv'
    if cluster_file.exists():
        city_clusters = pd.read_csv(cluster_file)
        results = run_prediction_by_cluster(panel, city_clusters, n_simulations=100000)
        
        # 城市级MC预测
        print("\n" + "=" * 60)
        print("城市级 Monte Carlo 预测")
        print("=" * 60)
        city_summary = run_prediction_by_city(panel, city_clusters, n_simulations=100000)
    else:
        print("\n[提示] 未找到聚类结果, 仅执行全局预测")
        
        # 全局预测
        scenarios = design_scenarios()
        base = panel[panel['year'] == panel['year'].max()]
        base_values = {
            'pop': base['pop_10k'].median(),
            'gdp_pc': base['gdp_per_capita'].median(),
            'urban': base['urbanization_rate'].median(),
            'industry2': base['industry2_share'].median(),
        }
        for k, v in base_values.items():
            if pd.isna(v):
                base_values[k] = {'pop': 50, 'gdp_pc': 60000, 'urban': 0.6, 'industry2': 0.4}[k]
        
        for key, scenario in scenarios.items():
            print(f"\n--- {scenario['name']} ---")
            simulate_trajectories(stirpat, base_values, scenario, n_simulations=100000)
