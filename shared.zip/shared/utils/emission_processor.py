"""
共享数据预处理模块 — emission_processor.py
============================================
加载、清洗、对齐三篇论文共用的排放数据和社会经济面板数据。

数据源:
    - CEADs: 290个中国城市 CO₂ 排放 1997-2019 (Mt CO₂)
    - EDGAR v2024: ~371个城市 CO₂ 排放 1970-2023 (吨)
    - 统计年鉴: GDP/人口/城镇化率/能源/产业结构

输出:
    - 统一的城市面板数据集 (long format): city, city_id, province, year, co2_mt, ...
"""

import os
import re
import warnings
import pandas as pd
import numpy as np
from pathlib import Path

warnings.filterwarnings('ignore', category=UserWarning, module='openpyxl')

# ============================================================
# 路径配置
# ============================================================
PROJECT_ROOT = Path(__file__).resolve().parents[2]
SHARED_DATA = PROJECT_ROOT / 'data' / 'raw'
CEADS_DIR = SHARED_DATA / 'ceads'
EDGAR_DIR = SHARED_DATA / 'edgar'
YEARBOOK_DIR = SHARED_DATA / 'yearbook'
GEO_DIR = SHARED_DATA / 'geo'

# ============================================================
# 省份前缀列表 (用于从 CEADs 城市名中去除省名前缀)
# ============================================================
_PROVINCE_PREFIXES = [
    '内蒙古', '黑龙江',  # 三字省份 (必须先匹配)
    '北京', '天津', '上海', '重庆',  # 直辖市 (这些不需要去前缀)
    '河北', '山西', '辽宁', '吉林', '江苏', '浙江', '安徽', '福建',
    '江西', '山东', '河南', '湖北', '湖南', '广东', '广西', '海南',
    '四川', '贵州', '云南', '西藏', '陕西', '甘肃', '青海', '宁夏', '新疆',
]

# 直辖市的城市名就是省名, 不需要去前缀
_MUNICIPALITIES = {'北京', '天津', '上海', '重庆'}


def _strip_province_prefix(name: str) -> str:
    """
    从 CEADs 格式的城市名中去除省名前缀.
    例: '云南昆明' → '昆明', '内蒙古包头' → '包头'
    但: '北京' → '北京' (直辖市保持不变)
    """
    if pd.isna(name):
        return name
    name = str(name).strip()
    
    # 直辖市不处理
    if name in _MUNICIPALITIES:
        return name
    
    # 按前缀长度从长到短匹配(内蒙古 > 云南)
    for prefix in sorted(_PROVINCE_PREFIXES, key=len, reverse=True):
        if prefix in _MUNICIPALITIES:
            continue
        if name.startswith(prefix) and len(name) > len(prefix):
            return name[len(prefix):]
    
    return name


def _strip_city_suffix(name: str) -> str:
    """去除城市后缀: '市' / '地区' / '盟'等."""
    if pd.isna(name):
        return name
    name = str(name).strip()
    # 保留特殊行政区名称 (如 "临夏回族自治州")
    for suffix in ['市', '地区']:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[:-len(suffix)]
    return name


def standardize_city_name(name: str, has_province_prefix: bool = False) -> str:
    """
    标准化城市名.
    
    Args:
        name: 原始城市名
        has_province_prefix: 是否含省名前缀 (CEADs 数据)
    
    Returns: 标准化后的城市名 (不含省名前缀和'市'后缀)
    """
    if pd.isna(name):
        return name
    name = str(name).strip()
    if has_province_prefix:
        name = _strip_province_prefix(name)
    name = _strip_city_suffix(name)
    return name


# ============================================================
# 数据加载函数
# ============================================================

def load_ceads_emissions() -> pd.DataFrame:
    """
    加载 CEADs 城市排放数据 (1997-2019, 290 cities).
    
    Returns:
        DataFrame: columns = [city_raw, city, year, co2_mt]
                   co2_mt 单位: 百万吨 CO₂ (Mt)
    """
    fpath = CEADS_DIR / '1997-2019年290个中国城市碳排放清单.xlsx'
    if not fpath.exists():
        raise FileNotFoundError(f"CEADs 数据文件不存在: {fpath}")
    
    df = pd.read_excel(fpath, sheet_name='emission vector', engine='openpyxl')
    df = df[['city', 'year', 'emission']].copy()
    df.columns = ['city_raw', 'year', 'co2_mt']
    df['year'] = df['year'].astype(int)
    df['co2_mt'] = pd.to_numeric(df['co2_mt'], errors='coerce')
    df = df.dropna(subset=['co2_mt'])
    
    # 提取省份和标准化城市名
    df['province'] = df['city_raw'].apply(
        lambda x: _extract_province(x) if pd.notna(x) else None
    )
    df['city'] = df['city_raw'].apply(
        lambda x: standardize_city_name(x, has_province_prefix=True)
    )
    df['source'] = 'CEADs'
    
    print(f"[CEADs] 加载完成: {df['city'].nunique()} 个城市, "
          f"{df['year'].min()}-{df['year'].max()}, {len(df)} 条记录")
    return df


def _extract_province(ceads_name: str) -> str:
    """从 CEADs 城市名中提取省份名."""
    if pd.isna(ceads_name):
        return None
    name = str(ceads_name).strip()
    
    # 直辖市
    if name in _MUNICIPALITIES:
        return name + '市'
    
    for prefix in sorted(_PROVINCE_PREFIXES, key=len, reverse=True):
        if prefix in _MUNICIPALITIES:
            continue
        if name.startswith(prefix) and len(name) > len(prefix):
            # 规范省份名: 加省/自治区后缀
            prov_map = {
                '内蒙古': '内蒙古自治区', '广西': '广西壮族自治区',
                '西藏': '西藏自治区', '宁夏': '宁夏回族自治区',
                '新疆': '新疆维吾尔自治区',
            }
            return prov_map.get(prefix, prefix + '省')
    
    return None


def load_edgar_emissions() -> pd.DataFrame:
    """
    加载 EDGAR v2024 城市排放数据 (1970-2023, ~371 cities).
    
    Returns:
        DataFrame: columns = [city_raw, city, city_id, province, year, co2_mt]
    """
    fpath = EDGAR_DIR / '1970～2023年中国各城市CO2总排放量(v2024_GHG).xlsx'
    if not fpath.exists():
        raise FileNotFoundError(f"EDGAR 数据文件不存在: {fpath}")
    
    df = pd.read_excel(fpath, sheet_name='Sheet1', engine='openpyxl')
    df.columns = ['province', 'province_id', 'city_raw', 'city_id', 'year', 'co2_ton']
    df['year'] = df['year'].astype(int)
    df['co2_ton'] = pd.to_numeric(df['co2_ton'], errors='coerce')
    df['co2_mt'] = df['co2_ton'] / 1e6  # 吨 → 百万吨
    df = df.drop(columns=['co2_ton', 'province_id'])
    
    # 标准化城市名
    df['city'] = df['city_raw'].apply(
        lambda x: standardize_city_name(x, has_province_prefix=False)
    )
    df['source'] = 'EDGAR'
    
    print(f"[EDGAR] 加载完成: {df['city'].nunique()} 个城市, "
          f"{df['year'].min()}-{df['year'].max()}, {len(df)} 条记录")
    return df


def harmonize_emissions(ceads: pd.DataFrame, edgar: pd.DataFrame,
                        year_range: tuple = (2001, 2023)) -> pd.DataFrame:
    """
    融合 CEADs 和 EDGAR 数据, 构建统一排放时序.
    
    策略:
        - 重叠期 (2001-2019): 使用 CEADs (学术认可度更高)
        - 2020-2023: 使用 EDGAR, 并用重叠期 CEADs/EDGAR 比值校正
        - CEADs 未覆盖的城市: 全期使用 EDGAR (不校正)
    """
    ceads = ceads.copy()
    edgar = edgar.copy()
    
    # ---- Step 1: 建立城市映射 ----
    # 获取 EDGAR 的 city_id 映射
    edgar_info = edgar[['city', 'city_id', 'province']].drop_duplicates('city')
    edgar_info.columns = ['city', 'edgar_city_id', 'edgar_province']
    
    # ---- Step 2: 计算校正比例 ----
    overlap_start = max(year_range[0], ceads['year'].min())
    overlap_end = min(2019, edgar['year'].max())
    
    ceads_ov = ceads[(ceads['year'] >= overlap_start) & 
                     (ceads['year'] <= overlap_end)][['city', 'year', 'co2_mt']]
    edgar_ov = edgar[(edgar['year'] >= overlap_start) & 
                     (edgar['year'] <= overlap_end)][['city', 'year', 'co2_mt']]
    
    merged_ov = ceads_ov.merge(edgar_ov, on=['city', 'year'], 
                               suffixes=('_ceads', '_edgar'), how='inner')
    
    if len(merged_ov) > 0:
        # 城市级比值中位数
        correction = merged_ov.groupby('city').apply(
            lambda g: (g['co2_mt_ceads'] / g['co2_mt_edgar'].replace(0, np.nan)).median(),
            include_groups=False
        ).reset_index()
        correction.columns = ['city', 'correction_ratio']
        correction = correction.dropna()
        
        matched_cities = len(correction)
        med_ratio = correction['correction_ratio'].median()
        print(f"[融合] 校正比例: {matched_cities} 个城市匹配, "
              f"中位比 = {med_ratio:.3f}, "
              f"范围 = [{correction['correction_ratio'].min():.2f}, "
              f"{correction['correction_ratio'].max():.2f}]")
    else:
        correction = pd.DataFrame(columns=['city', 'correction_ratio'])
        print("[融合] 警告: 无重叠数据")
    
    # ---- Step 3: 合并数据 ----
    result_parts = []
    
    ceads_cities = set(ceads['city'].unique())
    
    # Part 1: CEADs 城市在 2001-2019 → 使用 CEADs
    ceads_part = ceads[
        (ceads['year'] >= year_range[0]) & (ceads['year'] <= 2019)
    ][['city', 'province', 'year', 'co2_mt', 'source']].copy()
    # 补充 city_id
    ceads_part = ceads_part.merge(edgar_info[['city', 'edgar_city_id']], 
                                  on='city', how='left')
    ceads_part = ceads_part.rename(columns={'edgar_city_id': 'city_id'})
    result_parts.append(ceads_part)
    
    # Part 2: CEADs 城市在 2020-2023 → 使用校正后 EDGAR
    edgar_ext = edgar[
        (edgar['year'] > 2019) & (edgar['year'] <= year_range[1]) &
        (edgar['city'].isin(ceads_cities))
    ][['city', 'city_id', 'province', 'year', 'co2_mt', 'source']].copy()
    
    if len(correction) > 0 and len(edgar_ext) > 0:
        edgar_ext = edgar_ext.merge(correction, on='city', how='left')
        # 对有校正比的城市应用校正; 无校正比的用全局中位比
        global_ratio = correction['correction_ratio'].median()
        edgar_ext['correction_ratio'] = edgar_ext['correction_ratio'].fillna(global_ratio)
        edgar_ext['co2_mt'] = edgar_ext['co2_mt'] * edgar_ext['correction_ratio']
        edgar_ext = edgar_ext.drop(columns=['correction_ratio'])
        edgar_ext['source'] = 'EDGAR_corrected'
    result_parts.append(edgar_ext)
    
    # Part 3: 仅 EDGAR 城市 → 全期使用 EDGAR (不校正)
    edgar_only = edgar[
        (~edgar['city'].isin(ceads_cities)) &
        (edgar['year'] >= year_range[0]) & (edgar['year'] <= year_range[1])
    ][['city', 'city_id', 'province', 'year', 'co2_mt', 'source']].copy()
    result_parts.append(edgar_only)
    
    result = pd.concat(result_parts, ignore_index=True)
    result = result.sort_values(['city', 'year']).reset_index(drop=True)
    
    # 数据源统计
    src_counts = result.groupby('source')['city'].nunique()
    print(f"[融合] 最终: {result['city'].nunique()} 个城市, "
          f"{result['year'].min()}-{result['year'].max()}, {len(result)} 条")
    print(f"  来源分布: {dict(src_counts)}")
    
    return result


# ============================================================
# 统计年鉴数据加载
# ============================================================

def load_yearbook_wide(filename: str, subdir: str = None,
                       value_name: str = 'value') -> pd.DataFrame:
    """
    加载统计年鉴宽格式数据, 转为长格式.
    格式: PR, PR_ID, CITY, CITY_ID, CITY_TYPE, PR_TYPE, 2002, 2003, ...
    """
    fpath = YEARBOOK_DIR / subdir / filename if subdir else YEARBOOK_DIR / filename
    if not fpath.exists():
        raise FileNotFoundError(f"年鉴数据不存在: {fpath}")
    
    df = pd.read_excel(fpath, engine='openpyxl')
    
    # 识别年份列
    id_cols = [c for c in df.columns if not str(c).isdigit()]
    year_cols = [c for c in df.columns if str(c).isdigit()]
    
    if not year_cols:
        raise ValueError(f"无法识别年份列: {df.columns.tolist()}")
    
    # 宽 → 长
    df_long = df.melt(id_vars=id_cols, value_vars=year_cols,
                      var_name='year', value_name=value_name)
    df_long['year'] = df_long['year'].astype(int)
    df_long[value_name] = pd.to_numeric(df_long[value_name], errors='coerce')
    
    # 提取城市信息
    city_col = 'CITY' if 'CITY' in df_long.columns else df_long.columns[2]
    city_id_col = 'CITY_ID' if 'CITY_ID' in df_long.columns else df_long.columns[3]
    prov_col = 'PR' if 'PR' in df_long.columns else df_long.columns[0]
    
    result = df_long[[city_col, city_id_col, prov_col, 'year', value_name]].copy()
    result.columns = ['city', 'city_id', 'province', 'year', value_name]
    result['city'] = result['city'].apply(
        lambda x: standardize_city_name(x, has_province_prefix=False)
    )
    result = result.dropna(subset=[value_name])
    
    print(f"[年鉴] {filename}: {result['city'].nunique()} 城市, "
          f"{result['year'].min()}-{result['year'].max()}")
    return result


def load_energy_data() -> pd.DataFrame:
    """
    加载能源消费数据 (2006-2021).
    格式: 城市名(无标准格式), 2006, 2007, ...
    """
    fpath = YEARBOOK_DIR / '能源消费_2006-2021.xlsx'
    if not fpath.exists():
        fpath = YEARBOOK_DIR / '能源消费_原始_2006-2019.xlsx'
    if not fpath.exists():
        raise FileNotFoundError("能源消费数据不存在")
    
    df = pd.read_excel(fpath, engine='openpyxl')
    
    # 第一列是城市名, 其余是年份
    city_col = df.columns[0]
    year_cols = df.columns[1:]
    
    df_long = df.melt(id_vars=[city_col], value_vars=year_cols,
                      var_name='year', value_name='energy_consumption')
    df_long['year'] = pd.to_numeric(df_long['year'], errors='coerce').astype('Int64')
    df_long['energy_consumption'] = pd.to_numeric(df_long['energy_consumption'], errors='coerce')
    df_long = df_long.dropna(subset=['year', 'energy_consumption'])
    df_long['year'] = df_long['year'].astype(int)
    
    # 标准化城市名
    df_long['city'] = df_long[city_col].apply(
        lambda x: standardize_city_name(x, has_province_prefix=False)
    )
    
    result = df_long[['city', 'year', 'energy_consumption']]
    print(f"[能源] {result['city'].nunique()} 城市, "
          f"{result['year'].min()}-{result['year'].max()}")
    return result


def load_urbanization() -> pd.DataFrame:
    """加载城镇化率 (2000-2024)."""
    fpath = YEARBOOK_DIR / '中国地级市城镇化率（2000-2024年）.xlsx'
    if not fpath.exists():
        raise FileNotFoundError(f"城镇化率数据不存在: {fpath}")
    
    df = pd.read_excel(fpath, engine='openpyxl')
    df = df.iloc[:, :7]
    df.columns = ['city_id', 'year', 'province', 'city', 'region',
                  'hu_line', 'urbanization_rate']
    df['year'] = df['year'].astype(int)
    df['urbanization_rate'] = pd.to_numeric(df['urbanization_rate'], errors='coerce')
    df['city'] = df['city'].apply(
        lambda x: standardize_city_name(x, has_province_prefix=False)
    )
    result = df[['city', 'city_id', 'province', 'region', 'year',
                 'urbanization_rate']].dropna(subset=['urbanization_rate'])
    
    print(f"[城镇化率] {result['city'].nunique()} 城市, "
          f"{result['year'].min()}-{result['year'].max()}")
    return result


# ============================================================
# 面板数据构建
# ============================================================

def build_panel_dataset(year_range: tuple = (2001, 2023)) -> pd.DataFrame:
    """
    构建完整的城市面板数据集.
    
    Returns:
        DataFrame with columns:
            city, city_id, province, year, co2_mt, co2_source,
            gdp_100m, gdp_per_capita, pop_10k, urbanization_rate,
            industry2_share, industry3_share, energy_consumption,
            co2_per_capita, co2_intensity, region
    """
    print("=" * 60)
    print("构建城市面板数据集")
    print("=" * 60)
    
    # 1. 排放数据
    ceads = load_ceads_emissions()
    edgar = load_edgar_emissions()
    emissions = harmonize_emissions(ceads, edgar, year_range=year_range)
    panel = emissions.rename(columns={'source': 'co2_source'})
    
    # 2. GDP
    _merge_yearbook(panel, '地区生产总值当年价格_亿元_全市.xlsx',
                    'gdp_industrial', 'gdp_100m')
    
    # 3. 人均 GDP
    _merge_yearbook(panel, '人均地区生产总值_元_全市.xlsx',
                    'gdp_industrial', 'gdp_per_capita')
    
    # 4. 产业结构
    _merge_yearbook(panel, '第二产业占地区生产总值的比重_百分比_全市.xlsx',
                    'gdp_industrial', 'industry2_share')
    _merge_yearbook(panel, '第三产业占地区生产总值的比重_百分比_全市.xlsx',
                    'gdp_industrial', 'industry3_share')
    
    # 5. 人口 (多个来源合并取最优)
    _merge_population(panel)
    
    # 6. 城镇化率
    try:
        ur = load_urbanization()
        panel = panel.merge(ur[['city', 'year', 'urbanization_rate', 'region']],
                           on=['city', 'year'], how='left')
    except Exception as e:
        print(f"[警告] 城镇化率: {e}")
        panel['urbanization_rate'] = np.nan
        panel['region'] = np.nan
    
    # 7. 能源消费
    try:
        energy = load_energy_data()
        panel = panel.merge(energy[['city', 'year', 'energy_consumption']],
                           on=['city', 'year'], how='left')
    except Exception as e:
        print(f"[警告] 能源: {e}")
        panel['energy_consumption'] = np.nan
    
    # 8. 衍生指标
    panel['co2_per_capita'] = np.where(
        panel['pop_10k'] > 0,
        panel['co2_mt'] * 100 / panel['pop_10k'],  # Mt→万吨, /万人 = 吨/人
        np.nan
    )
    panel['co2_intensity'] = np.where(
        panel['gdp_100m'] > 0,
        panel['co2_mt'] / panel['gdp_100m'] * 100,  # 万吨/亿元
        np.nan
    )
    
    panel = panel.sort_values(['city', 'year']).reset_index(drop=True)
    
    # 输出报告
    print("=" * 60)
    n_cities = panel['city'].nunique()
    print(f"面板数据构建完成:")
    print(f"  城市: {n_cities}")
    print(f"  年份: {panel['year'].min()}-{panel['year'].max()} "
          f"({panel['year'].nunique()} 年)")
    print(f"  记录: {len(panel)}")
    
    key_cols = ['co2_mt', 'gdp_100m', 'pop_10k', 'urbanization_rate',
                'industry2_share', 'energy_consumption']
    for col in key_cols:
        if col in panel.columns:
            rate = panel[col].notna().mean()
            print(f"  {col}: {rate:.1%} 完整")
    print("=" * 60)
    
    return panel


def _merge_yearbook(panel: pd.DataFrame, filename: str, subdir: str,
                    value_name: str) -> None:
    """将年鉴数据左连接到面板 (in-place)."""
    try:
        df = load_yearbook_wide(filename, subdir=subdir, value_name=value_name)
        merged = panel.merge(df[['city', 'year', value_name]],
                            on=['city', 'year'], how='left')
        panel[value_name] = merged[value_name]
    except Exception as e:
        print(f"[警告] {value_name}: {e}")
        panel[value_name] = np.nan


def _merge_population(panel: pd.DataFrame) -> None:
    """
    合并人口数据: 优先使用年平均人口, 不足部分用户籍人口补充.
    """
    pop_data = []
    
    # 来源 1: 年平均人口 (2001-2019)
    try:
        pop_avg = load_yearbook_wide('年平均人口_万人_全市.xlsx',
                                     subdir='population', value_name='pop_10k')
        pop_data.append(pop_avg[['city', 'year', 'pop_10k']])
    except Exception as e:
        print(f"[人口] 年平均人口加载失败: {e}")
    
    # 来源 2: 常住人口 (2020-2023)
    try:
        pop_res = load_yearbook_wide('常住人口_万人_全市.xlsx',
                                     subdir='population', value_name='pop_10k')
        pop_data.append(pop_res[['city', 'year', 'pop_10k']])
    except Exception as e:
        print(f"[人口] 常住人口加载失败: {e}")
    
    # 来源 3: 户籍人口 (1999-2022) 作为补充
    try:
        pop_hj = load_yearbook_wide('户籍人口_万人_全市.xlsx',
                                    subdir='population', value_name='pop_10k_hj')
        pop_data.append(pop_hj[['city', 'year', 'pop_10k_hj']].rename(
            columns={'pop_10k_hj': 'pop_10k'}))
    except Exception as e:
        print(f"[人口] 户籍人口加载失败: {e}")
    
    if pop_data:
        # 合并去重: 优先保留前面的来源
        pop_combined = pd.concat(pop_data, ignore_index=True)
        pop_combined = pop_combined.drop_duplicates(subset=['city', 'year'], keep='first')
        merged = panel.merge(pop_combined[['city', 'year', 'pop_10k']],
                            on=['city', 'year'], how='left')
        panel['pop_10k'] = merged['pop_10k']
    else:
        panel['pop_10k'] = np.nan


# ============================================================
# 便捷函数
# ============================================================

def save_panel(panel: pd.DataFrame, filename: str = 'city_panel.csv'):
    """Save a locally constructed panel to data/derived/."""
    outpath = PROJECT_ROOT / 'data' / 'derived' / filename
    outpath.parent.mkdir(parents=True, exist_ok=True)
    panel.to_csv(outpath, index=False, encoding='utf-8-sig')
    size_mb = outpath.stat().st_size / 1e6
    print(f"已保存: {outpath} ({len(panel)} 行, {size_mb:.1f} MB)")
    return outpath


def load_panel(filename: str = 'city_panel.csv') -> pd.DataFrame:
    """Load a locally obtained panel from data/derived/."""
    fpath = PROJECT_ROOT / 'data' / 'derived' / filename
    if not fpath.exists():
        raise FileNotFoundError(f"面板数据不存在: {fpath}\n请先运行: python -m shared.utils.emission_processor")
    return pd.read_csv(fpath)


def get_emission_ts(panel: pd.DataFrame = None,
                    source: str = 'all') -> pd.DataFrame:
    """
    获取排放时序子集, 用于论文 2 DTW 聚类.
    
    Args:
        panel: 面板数据, None 则自动加载
        source: 'ceads' 仅 CEADs 城市, 'all' 全部城市
    
    Returns:
        DataFrame: city × year 的宽格式排放矩阵
    """
    if panel is None:
        panel = load_panel()
    
    if source == 'ceads':
        panel = panel[panel['co2_source'].isin(['CEADs', 'EDGAR_corrected'])]
    
    pivot = panel.pivot_table(index='city', columns='year', 
                              values='co2_mt', aggfunc='first')
    
    # 报告缺失
    miss_rate = pivot.isna().mean(axis=1)
    complete = (miss_rate == 0).sum()
    print(f"[排放时序] {len(pivot)} 城市, {pivot.columns.min()}-{pivot.columns.max()}")
    print(f"  完整时序: {complete} 城市, 平均缺失率: {miss_rate.mean():.1%}")
    
    return pivot


# ============================================================
# 主入口
# ============================================================

if __name__ == '__main__':
    panel = build_panel_dataset(year_range=(2001, 2023))
    save_panel(panel)
    
    # 排放时序矩阵
    print("\n--- CEADs 城市排放时序 ---")
    ts_ceads = get_emission_ts(panel, source='ceads')
    
    print("\n--- 全部城市排放时序 ---")
    ts_all = get_emission_ts(panel, source='all')
    
    # 数据质量报告
    print("\n=== 数据源统计 ===")
    print(panel.groupby('co2_source')['city'].nunique())
    
    print("\n=== 各变量缺失率 ===")
    miss = panel.isnull().mean().sort_values(ascending=False)
    for col, rate in miss.items():
        if rate > 0:
            print(f"  {col}: {rate:.1%}")
